# Python Packaging: From Source Tree to Installed TorKit Command

> Repository snapshot used by this chapter: `BrentDean/torKit`, `main`, 2026-08-01.
>
> TorKit already has a real Python package configuration. This chapter explains the machinery behind it: why packaging exists, why Python packaging became complicated, what `pyproject.toml` replaced, how Hatchling participates, why the project uses `src/`, and what an editable install actually changes.

## Learning goals

After completing this chapter, you should be able to:

- distinguish an import package, a distribution package, a source tree, a source distribution, and a wheel;
- explain the roles of pip, a build frontend, and a build backend;
- describe why Python moved from direct `setup.py` execution toward `pyproject.toml` and standardized build interfaces;
- interpret every packaging-related line in TorKit's `pyproject.toml`;
- explain how `[project.scripts]` creates the `torkit` command;
- explain why editable installs exist and what they do not update automatically;
- build and inspect TorKit artifacts without publishing them;
- compare Hatchling with Setuptools, Flit, Poetry, PDM, and other alternatives;
- diagnose common packaging failures rather than reinstalling randomly.

---

## 1. Why packaging exists

A source directory is not yet a portable software product.

Imagine copying only this directory to another machine:

```text
src/torkit/
├── __init__.py
└── cli.py
```

Several questions remain unanswered:

- What is the project called?
- Which Python versions are supported?
- What license applies?
- Which external libraries are required?
- Which files belong in an installation?
- Should a command-line program be created?
- How should the project be built?
- How can another tool install it without executing arbitrary project-specific commands?

Packaging is the system that answers those questions in a machine-readable form and turns a source tree into installable artifacts.

```text
source tree
    │
    ├── source code
    ├── metadata
    ├── build configuration
    ├── license/readme
    └── optional non-code resources
             │
             ▼
        build backend
             │
       ┌─────┴─────┐
       ▼           ▼
     sdist        wheel
       │           │
       └─────┬─────┘
             ▼
       installer such as pip
             │
             ▼
      environment/site-packages
      generated console scripts
```

The packaging system separates three concerns:

1. **Project authorship** — declaring what the project is.
2. **Building** — turning source into standard artifacts.
3. **Installing** — placing an artifact into a selected Python environment.

These concerns were historically mixed together, which is one reason Python packaging acquired a reputation for confusion.

---

## 2. Essential terminology

### Source tree

The checked-out project directory containing editable source and configuration:

```text
torKit/
├── docs/
├── src/
├── tests/
├── scripts/
├── pyproject.toml
└── README.md
```

### Import package

A package imported by Python:

```python
import torkit
```

Its source currently lives under `src/torkit/`.

### Distribution package

The installable project described by packaging metadata:

```toml
[project]
name = "torkit"
```

Package indexes, installers, dependency resolvers, and metadata tools operate on the distribution.

### Module

An importable Python unit such as `torkit.cli`, normally backed by `src/torkit/cli.py`.

### Source distribution (`sdist`)

An archive containing source and build metadata, commonly named like:

```text
torkit-0.1.0.tar.gz
```

Installing an sdist normally requires building a wheel first. This can require compilers or other build dependencies if the project contains native extensions.

### Wheel

A built distribution using the `.whl` format:

```text
torkit-0.1.0-py3-none-any.whl
```

The tags communicate compatibility:

- `py3` — compatible with Python 3 according to the wheel metadata;
- `none` — no specific Python ABI;
- `any` — not tied to one operating-system platform.

For current TorKit, which contains only pure Python, a universal pure-Python wheel is expected.

### Build frontend

A user-facing tool that requests builds, such as `python -m build` or pip during installation.

### Build backend

The project-selected implementation that knows how to build the project. TorKit selects Hatchling:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

### Installer

A tool that places distributions into an environment. pip is the standard example.

### Package index

A service that stores and serves distributions and metadata. PyPI is the public Python Package Index. TorKit does not need to be uploaded to PyPI merely because it is packaged.

---

## 3. The historical problem: `setup.py` did too much

Early Python packaging grew around `distutils` and project-specific `setup.py` files. A typical project used Python code like:

```python
from setuptools import setup

setup(
    name="example",
    version="1.0.0",
    packages=["example"],
)
```

The file served multiple roles:

- metadata declaration;
- package discovery configuration;
- build instructions;
- command-line interface;
- executable Python code.

Users were taught commands such as:

```bash
python setup.py install
python setup.py sdist
python setup.py bdist_wheel
python setup.py develop
```

This design created several problems.

### 3.1 The build tool had to be known before the build could start

To execute `setup.py`, the environment already needed the correct build library, often Setuptools. But the project had no standardized way to declare that build requirement before execution.

### 3.2 Builds could depend on the caller's environment

A project might import a package from inside `setup.py`. Whether the build succeeded could depend on whatever happened to be globally installed.

### 3.3 The project file was executable code

Reading metadata could execute arbitrary Python. Tools could not always inspect basic project information without running project-controlled code.

### 3.4 Alternative build systems lacked a common protocol

The ecosystem was centered around Setuptools behavior. A new backend needed a standard way to tell pip how to build without pretending to be `setup.py`.

### 3.5 Direct commands coupled users to backend implementation

A user should ask for “build this project” or “install this project,” not call an internal backend script with backend-specific command names.

The modern system did not abolish Setuptools. It standardized the boundary around build backends.

---

## 4. The standards transition

Python packaging modernization occurred through several related standards.

### PEP 518: declare build requirements

`pyproject.toml` introduced a place to declare what is needed to build a project:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

A frontend can create an isolated build environment and install Hatchling there before requesting a build.

### PEP 517: standard backend hooks

PEP 517 defined an interface between build frontends and build backends. The frontend does not need a project-specific command. It invokes standardized hooks for operations such as building a wheel or source distribution.

Conceptually:

```text
python -m build
      │
      ▼
reads [build-system]
      │
      ▼
creates isolated build environment
      │
      ▼
installs hatchling
      │
      ▼
calls standardized backend hooks
      │
      ▼
Hatchling builds artifacts
```

### PEP 621: standard project metadata

PEP 621 standardized core metadata under `[project]` in `pyproject.toml`:

```toml
[project]
name = "torkit"
version = "0.1.0"
description = "A modular toolkit for building Tor-based applications."
```

Backends can share the same metadata format instead of inventing a new syntax for names, versions, dependencies, and entry points.

### PEP 660: editable installs for modern backends

Legacy editable installs depended heavily on Setuptools' `setup.py develop`. PEP 660 defined editable-install hooks for `pyproject.toml`-based builds.

The goal is that Python source remains in the working tree while the environment treats the project as installed. Entry points and dependencies are still installed into the environment.

### The result

Modern commands target standardized operations:

```bash
python -m pip install .
python -m pip install -e .
python -m build
```

The deprecated pattern is direct execution of backend commands:

```bash
python setup.py install
python setup.py develop
python setup.py sdist
```

A project may still contain `setup.py`, especially when using Setuptools, but users should not treat it as the universal packaging command interface.

---

## 5. TorKit's `pyproject.toml`, line by line

The current file is:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "torkit"
version = "0.1.0"
description = "A modular toolkit for building Tor-based applications."
readme = "README.md"
requires-python = ">=3.11"
license = "GPL-3.0-or-later"
authors = [
    { name = "Brent Dean" }
]
dependencies = []

[project.scripts]
torkit = "torkit.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/torkit"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

Each table belongs to a different authority.

```text
[build-system]                 standardized packaging table
[project]                      standardized project metadata
[project.scripts]              standardized entry-point metadata
[tool.hatch....]               Hatch-specific configuration
[tool.pytest....]              pytest-specific configuration
```

### `[build-system]`

```toml
requires = ["hatchling"]
```

The isolated build environment needs Hatchling. This list is for **build requirements**, not application runtime dependencies.

```toml
build-backend = "hatchling.build"
```

The frontend imports this backend and calls standardized hooks.

A common mistake is to place all application dependencies under `build-system.requires`. Doing so confuses “needed to build” with “needed when the installed program runs.”

### `[project] name`

```toml
name = "torkit"
```

This is the distribution name used in metadata and installation records. Distribution name comparison is normalized by packaging tools, so punctuation and case are not always significant in the way a filename is.

It does not directly tell Python which import package exists. Hatchling's package configuration does that.

### Version

```toml
version = "0.1.0"
```

This is a statically declared release version. A later project may derive versions from Git tags or a source file, but that adds machinery. For an early educational project, one explicit version is easier to inspect.

Version changes affect built metadata. Editing this line in an editable installation may require reinstalling before tools and generated metadata observe the new value.

### Description and readme

```toml
description = "A modular toolkit for building Tor-based applications."
readme = "README.md"
```

The description is short metadata. The readme points to a longer project description that can be included in distribution metadata.

### Python requirement

```toml
requires-python = ">=3.11"
```

Installers use this to reject incompatible interpreters. It also declares the project's compatibility promise.

This line does not install Python 3.11. It says that an installer must use a compatible Python interpreter.

A project should not claim a lower minimum version merely to look compatible. The declared range should be backed by testing.

### License

```toml
license = "GPL-3.0-or-later"
```

This uses an SPDX license expression. It communicates licensing metadata to packaging tools. It does not replace the need for the actual license text in the repository and distribution.

### Authors

```toml
authors = [
    { name = "Brent Dean" }
]
```

This is an array of inline tables because a project can have multiple authors, and each entry can contain structured fields.

### Runtime dependencies

```toml
dependencies = []
```

TorKit currently declares no third-party runtime packages. The list will grow only when implemented code imports an external dependency needed by installed users.

A future example might be:

```toml
dependencies = [
    "stem>=1.8,<2",
]
```

Version constraints should reflect actual compatibility and risk. Pinning every transitive dependency exactly in library metadata is usually inappropriate; application reproducibility may use a separate lock mechanism.

### Console script

```toml
[project.scripts]
torkit = "torkit.cli:main"
```

The key is the command name. The value identifies an importable object.

```text
torkit            torkit.cli            main
command name  →   Python module    →    callable
```

After installation, the environment contains an executable wrapper. On Unix-like systems it is commonly placed under the environment's `bin/`; on Windows, under `Scripts\`.

The wrapper imports `torkit.cli` and calls `main`. Therefore:

- the package must be importable;
- `main` must exist;
- import-time failures prevent the command from starting;
- changing the entry-point mapping requires reinstalling, even in editable mode.

### Hatch wheel package selection

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/torkit"]
```

This tells Hatchling which package directory belongs in the wheel. The path is from the repository root. The installed package becomes `torkit`, not `src.torkit`.

### Pytest configuration

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

This is not packaging metadata. It is pytest configuration sharing the TOML file under the reserved `[tool]` namespace.

`testpaths` directs discovery toward `tests/`. `pythonpath` adds `src` during pytest execution. That can make tests import TorKit without installation, but an editable install remains important because it exercises the console script and installed metadata.

---

## 6. Why TorKit uses the `src/` layout

Two common layouts are:

### Flat layout

```text
project/
├── torkit/
│   ├── __init__.py
│   └── cli.py
├── tests/
└── pyproject.toml
```

### `src/` layout

```text
project/
├── src/
│   └── torkit/
│       ├── __init__.py
│       └── cli.py
├── tests/
└── pyproject.toml
```

Python normally places the current working directory early on `sys.path`. In a flat layout, running tests from the repository root may import the source directory even when the built wheel accidentally omits files or has broken configuration.

The `src/` layout forces a more honest model:

```text
repository root is not automatically the import package
                    │
                    ▼
project must be installed or src explicitly added
                    │
                    ▼
imports more closely resemble user installation
```

This catches packaging errors earlier.

### Tradeoff

The layout adds one setup step. A developer cannot assume `import torkit` works from the repository root in every Python process. That is intentional. Use an editable installation inside a virtual environment.

---

## 7. Editable installs

Install TorKit for development:

```bash
python -m pip install -e .
```

The `.` means “the project in the current directory.” The `-e` means editable.

### What the developer expects

After installation:

```bash
torkit
```

prints:

```text
TorKit
```

If `src/torkit/cli.py` changes to print a different string, a new process should import the changed source without a full reinstall.

### Conceptual model

A normal installation copies built package contents into the environment:

```text
working tree ──build/install──► site-packages/torkit/
```

An editable installation arranges for the environment to import from the working tree while still installing metadata and scripts:

```text
site-packages metadata/linkage
          │
          └────────► repository/src/torkit/

bin/torkit wrapper
          │
          └────────► torkit.cli:main
```

The exact mechanism is backend-dependent. It may involve a path configuration file, import hook, or editable wheel machinery.

### What does not automatically update

Source code changes normally take effect in a new Python process. Changes to packaging configuration may require reinstalling:

- adding or changing a console script;
- adding dependencies;
- changing package discovery;
- changing project metadata;
- changing build configuration.

Run again:

```bash
python -m pip install -e .
```

### Editable does not mean globally safe

Editable installation should happen inside a project virtual environment. Installing an in-development application into the operating system's Python can conflict with system packages and obscure which code is active.

---

## 8. Building TorKit locally

Install the build frontend in the active environment:

```bash
python -m pip install build
```

Build both standard artifacts:

```bash
python -m build
```

Expected output directory:

```text
dist/
├── torkit-0.1.0-py3-none-any.whl
└── torkit-0.1.0.tar.gz
```

`dist/` is generated output and should not be treated as source.

### Inspect the wheel without installing it

A wheel is a ZIP-format archive:

```bash
python -m zipfile -l dist/torkit-0.1.0-py3-none-any.whl
```

You should expect package files and metadata similar to:

```text
torkit/__init__.py
torkit/cli.py
torkit-0.1.0.dist-info/METADATA
torkit-0.1.0.dist-info/WHEEL
torkit-0.1.0.dist-info/entry_points.txt
torkit-0.1.0.dist-info/RECORD
```

The entry-point file should describe the `torkit` command.

### Inspect metadata

```bash
python - <<'PY'
from pathlib import Path
from zipfile import ZipFile

wheel = next(Path("dist").glob("*.whl"))
with ZipFile(wheel) as archive:
    metadata_name = next(
        name for name in archive.namelist()
        if name.endswith(".dist-info/METADATA")
    )
    print(archive.read(metadata_name).decode())
PY
```

### Test in a fresh environment

A build should be tested independently of the working editable environment:

```bash
python -m venv /tmp/torkit-wheel-test
source /tmp/torkit-wheel-test/bin/activate
python -m pip install dist/torkit-0.1.0-py3-none-any.whl
torkit
python -c 'import torkit; print(torkit.__file__)'
deactivate
rm -rf /tmp/torkit-wheel-test
```

The import path should point into the temporary environment, not the source tree.

This test catches a class of error that editable installs can hide.

---

## 9. Build isolation

When a modern frontend builds a project, it normally creates an isolated environment containing only declared build requirements.

Why?

Suppose your development environment happens to contain:

```text
hatchling
setuptools
cython
some-private-helper
```

If the build accidentally imports `some-private-helper`, it may succeed for you and fail for everyone else. Build isolation limits the build to dependencies declared under `[build-system]` or requested through standardized hooks.

```text
developer environment
    many packages
          │
          │ build request
          ▼
temporary isolated build environment
    hatchling only (plus required support)
          │
          ▼
        artifacts
```

Isolation improves reproducibility but does not guarantee bit-for-bit identical output. Timestamps, platform-specific compilation, generated files, and dependency versions may still matter.

### Offline implications

An isolated builder may try to download Hatchling if it is not available from a configured local source. For offline or controlled builds, cache or mirror build requirements and runtime dependencies. “The source has no dependencies” does not mean “the build needs no tools.”

---

## 10. Runtime dependencies, development tools, and lock files

These categories should not be mixed.

### Runtime dependency

Needed by an installed TorKit feature:

```toml
[project]
dependencies = [
    "example-library>=2",
]
```

### Optional dependency

Needed only for an optional feature:

```toml
[project.optional-dependencies]
desktop = ["PySide6>=6.7"]
tor = ["stem>=1.8"]
```

This is only an example; TorKit should add groups when real implemented features require them.

### Development dependency

Needed to test, lint, type-check, or build the project but not to run the installed application. Core metadata does not prescribe one universal development-dependency workflow. Backends and environment managers offer different mechanisms.

Possible approaches include:

- optional dependency groups such as `dev`;
- standardized dependency groups supported by current tooling;
- a lock file managed by Poetry, PDM, uv, or another environment tool;
- separate requirement files;
- Hatch environments.

### Library constraints versus application locks

A reusable library usually declares compatible ranges so it can coexist with other packages. A deployed application often wants a lock file to reproduce a tested environment.

```text
library metadata:       stem>=1.8,<2
application lock:       stem==1.8.2 plus exact transitive versions
```

TorKit is an application/toolkit hybrid. The project should decide which installation scenarios it supports before selecting a locking strategy.

---

## 11. Hatchling and alternatives

### Hatchling

TorKit currently uses Hatchling as its build backend. It is the backend associated with the Hatch project and supports modern `pyproject.toml` builds without requiring `setup.py`.

Why it fits the current project:

- concise configuration;
- modern standards support;
- straightforward pure-Python wheel building;
- explicit package selection for the `src/` layout;
- no legacy configuration required for the current package.

### Setuptools

Setuptools is the most established general-purpose backend in Python packaging. It supports many legacy and advanced patterns, package discovery modes, extension modules, and migration paths.

Choose it when:

- existing project history already uses it;
- required features or plugins are Setuptools-specific;
- native extension configuration fits its ecosystem;
- compatibility with older packaging workflows matters.

Its breadth is valuable, but an educational project can encounter more historical concepts than it needs.

### Flit

Flit emphasizes simple packaging of Python modules and packages. It is attractive for small pure-Python libraries with minimal build customization.

### Poetry

Poetry combines dependency management, lock files, environment handling, publishing, and a build backend. This integrated workflow is convenient but introduces tool-specific project management behavior beyond the build standard itself.

### PDM

PDM provides project and dependency management around modern standards, including lock and environment workflows.

### uv

uv is a fast package and project tool that can manage Python versions, environments, dependency resolution, locking, and commands. It can act as a frontend around standard project metadata. Its rapid evolution means project policy should be documented if adopted.

### Choosing tools without confusing roles

A project can use one tool as a build backend and another as an installer or environment manager.

```text
Hatchling       build backend
pip             installer
build           build frontend
venv            environment creator
pytest          test runner
```

Do not assume “we use Hatchling” means every developer command must use the Hatch CLI.

---

## 12. How OnionShare relates to packaging

Upstream OnionShare is a Python project distributed through several channels, including platform-specific application packages and Python-oriented development workflows. Historical OnionShare development documentation used Poetry commands, while the upstream repository continues to evolve its `pyproject.toml` metadata and packaging structure.

This illustrates an important distinction:

```text
Python project packaging
        is one layer

Desktop distribution
Flatpak / Snap
Windows / macOS bundles
OS package repositories
        are additional layers
```

A wheel can install Python code and console scripts, but it does not automatically solve:

- shipping a Tor binary;
- desktop integration;
- Qt runtime packaging;
- sandbox policy;
- application signing;
- operating-system installers;
- update channels.

TorKit's current `pyproject.toml` establishes only the Python package foundation. It should not be mistaken for a complete end-user distribution plan.

The upstream architecture also reinforces why the shared Python core and desktop frontend can have distinct packaging concerns. TorKit's architecture plans a reusable backend with thin frontends, allowing later distribution work to package those layers appropriately.

---

## 13. Common packaging mistakes

### Mistake 1: Confusing the repository name with the import name

The GitHub repository is `BrentDean/torKit`. The distribution is `torkit`. The import package is `torkit`. The command is `torkit`. These happen to align closely, but they are separate identifiers.

### Mistake 2: Installing globally with `sudo pip`

This can overwrite files managed by the operating system or create permissions problems. Use a virtual environment for development.

### Mistake 3: Using bare `pip`

```bash
pip install -e .
```

may target a different interpreter than expected. Prefer:

```bash
python -m pip install -e .
```

### Mistake 4: Assuming editable mode updates metadata changes

Changing `src/torkit/cli.py` normally takes effect immediately in a new process. Changing `[project.scripts]` requires reinstalling.

### Mistake 5: Testing only from the repository root

The current directory and pytest configuration may make imports succeed even if the wheel is wrong. Install the built wheel into a clean environment.

### Mistake 6: Adding undeclared imports

If code adds:

```python
import stem
```

but `dependencies` remains empty, development may work because Stem is already installed locally. Fresh installs will fail.

### Mistake 7: Putting runtime packages in `build-system.requires`

Build dependencies and runtime dependencies solve different problems.

### Mistake 8: Committing generated environments or build output

Normally exclude:

```text
.venv/
build/
dist/
*.egg-info/
__pycache__/
```

Generated artifacts can be recreated. Source and configuration are authoritative.

### Mistake 9: Publishing before testing metadata

A public package name is difficult to reclaim, and releases should normally be immutable. Build locally, inspect artifacts, and test clean installation first.

### Mistake 10: Treating a lock file as a substitute for project metadata

A lock file reproduces one resolved environment. Installers still need correct project metadata, package inclusion, entry points, and Python compatibility.

---

## 14. Diagnostic commands

### Confirm interpreter and pip alignment

```bash
which python
python --version
python -m pip --version
```

On Windows PowerShell:

```powershell
Get-Command python
python --version
python -m pip --version
```

### Show installed TorKit metadata

```bash
python -m pip show torkit
```

### Locate the imported package

```bash
python -c 'import torkit; print(torkit.__file__)'
```

### Locate the command

```bash
command -v torkit
```

### Inspect entry points through Python

```bash
python - <<'PY'
from importlib.metadata import distribution

metadata = distribution("torkit")
print("version:", metadata.version)
for entry in metadata.entry_points:
    if entry.group == "console_scripts":
        print(entry.name, "->", entry.value)
PY
```

### Remove and recreate the editable install

```bash
python -m pip uninstall torkit
python -m pip install -e .
```

Do this only inside the intended environment.

### Verify build contents

```bash
rm -rf build dist
python -m build
python -m zipfile -l dist/*.whl
```

A clean build avoids inspecting stale artifacts from an earlier configuration.

---

## 15. Laboratory exercises

### Exercise 1: Identify all names

For TorKit, write down the current values of:

- repository name;
- distribution name;
- import package;
- module containing the CLI;
- generated command;
- callable entry point.

Explain why each could theoretically differ.

### Exercise 2: Build and list artifacts

```bash
python -m build
ls -lh dist/
```

Explain the purpose of each artifact. Do not upload them.

### Exercise 3: Inspect the wheel

List every file in the wheel. Confirm that `docs/`, `tests/`, and `scripts/` are not automatically import packages in the wheel.

### Exercise 4: Read installed metadata

Use `importlib.metadata` to print:

- name;
- version;
- Python requirement;
- license;
- console scripts.

Compare the output with `pyproject.toml`.

### Exercise 5: Prove editable behavior

1. Install TorKit editable in a disposable environment.
2. Run `torkit`.
3. Temporarily change the printed string in `src/torkit/cli.py`.
4. Run `torkit` again in a new process.
5. Revert the source change.

Explain why no rebuild was required.

### Exercise 6: Prove entry-point metadata is different

Temporarily rename the script key in `pyproject.toml` from `torkit` to `torkit-demo` without reinstalling. Check which commands exist. Reinstall editable and check again. Revert and reinstall.

### Exercise 7: Test the wheel in isolation

Create a temporary environment, install only the wheel, and run both:

```bash
torkit
python -c 'from torkit.cli import main; main()'
```

Record the import path.

### Exercise 8: Break package selection safely

In a disposable copy, change Hatch's package path to a nonexistent directory and build. Read the error rather than immediately changing tools. Explain which layer rejected the configuration.

### Exercise 9: Compare normal and editable installations

Create two temporary environments. Install `.` normally in one and `-e .` in the other. Print `torkit.__file__` in both. Explain the difference.

### Exercise 10: Design future optional dependencies

Assume TorKit eventually has:

- a core CLI with no GUI;
- optional Qt desktop support;
- optional Tor control support;
- test and lint tools.

Sketch a `pyproject.toml` dependency organization. Label which entries are runtime, optional, and development-only. Do not add it to the repository yet.

---

## 16. Review questions

1. Why is `pyproject.toml` more than a replacement filename for `setup.py`?
2. What role does Hatchling play, and what role does pip play?
3. Why can a source distribution require more tools to install than a wheel?
4. What problem does build isolation reduce?
5. Why does TorKit explicitly identify `src/torkit` for the wheel?
6. What changes normally require reinstalling an editable project?
7. Why should a built wheel be tested in a clean environment?
8. How does `[project.scripts]` connect a shell command to Python code?
9. What is the difference between application dependencies and build requirements?
10. Why is Python packaging only one part of distributing a desktop application like OnionShare?

---

## 17. Further reading and primary sources

- Python Packaging User Guide: <https://packaging.python.org/>
- Packaging Python projects: <https://packaging.python.org/en/latest/tutorials/packaging-projects/>
- Writing `pyproject.toml`: <https://packaging.python.org/en/latest/guides/writing-pyproject-toml/>
- `src` layout versus flat layout: <https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/>
- Installing local projects and editable projects: <https://packaging.python.org/en/latest/tutorials/installing-packages/>
- Modernizing `setup.py` projects: <https://packaging.python.org/en/latest/guides/modernize-setup-py-project/>
- PEP 517, build-system interfaces: <https://peps.python.org/pep-0517/>
- PEP 518, build requirements in `pyproject.toml`: <https://peps.python.org/pep-0518/>
- PEP 621, project metadata: <https://peps.python.org/pep-0621/>
- PEP 660, editable installs: <https://peps.python.org/pep-0660/>
- Wheel specification: <https://packaging.python.org/en/latest/specifications/binary-distribution-format/>
- Hatchling documentation: <https://hatch.pypa.io/latest/config/build/>
- OnionShare development documentation: <https://docs.onionshare.org/2.6.4/en/develop.html>

---

## Chapter summary

Python packaging exists because source code alone does not state how a project should be identified, built, installed, or exposed to users. The modern system separates frontends, backends, installers, metadata, and artifacts through standardized interfaces. TorKit uses `pyproject.toml`, Hatchling, a `src/` layout, and a console-script entry point to create a small but complete package foundation.

The practical workflow is straightforward when the roles are clear: create an isolated environment, install TorKit editable during development, run tests against the package, build a wheel and sdist, inspect them, and test the wheel in a clean environment. The complexity becomes manageable once “pip,” “Hatchling,” “wheel,” “distribution,” and “import package” stop being treated as synonyms.
