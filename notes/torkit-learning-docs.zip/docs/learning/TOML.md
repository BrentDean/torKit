# TOML: The Configuration Language in `pyproject.toml`

> Repository snapshot used by this chapter: `BrentDean/torKit`, `main`, 2026-08-01.
>
> TorKit's build, project metadata, entry point, wheel configuration, and pytest settings currently live in one TOML file. This chapter teaches TOML as a data format and then shows how several independent tools assign meaning to that data.

## Learning goals

After completing this chapter, you should be able to:

- explain what problem TOML was designed to solve;
- compare TOML with JSON, YAML, INI, and executable configuration;
- read and write TOML values, arrays, tables, dotted keys, inline tables, and arrays of tables;
- explain why TOML syntax and `pyproject.toml` semantics are separate concerns;
- map TorKit's `pyproject.toml` into a nested data structure;
- identify invalid duplicate definitions and common quoting mistakes;
- use Python's `tomllib` to inspect configuration safely;
- determine which tool owns each TorKit configuration table;
- design small experiments that distinguish parser errors from tool-specific validation errors.

---

## 1. Why configuration formats exist

Programs need values that change without rewriting program logic. Examples include:

- project names and versions;
- dependency lists;
- build backends;
- test directories;
- network ports;
- feature toggles;
- user preferences.

Hard-coding every value in Python creates unnecessary coupling:

```python
PROJECT_NAME = "torkit"
BUILD_BACKEND = "hatchling.build"
TEST_PATHS = ["tests"]
```

A build frontend written in another language cannot easily consume those values without executing Python. A configuration format gives tools a shared data representation.

The central design problem is a tradeoff:

```text
human readability
      ▲
      │
      │        TOML aims here
      │
      └────────────────────► expressive power

simple formats                     executable code
few surprises                      unlimited behavior
limited data model                 difficult to inspect safely
```

TOML was designed to be obvious to read and to map unambiguously into a table-like data structure. Its name originally expanded to “Tom's Obvious, Minimal Language.” The format avoids becoming a programming language: it has values and structure, but no loops, functions, imports, or conditional execution.

That constraint is a feature. Tools can parse metadata without running project-controlled code.

---

## 2. What TOML is—and is not

TOML is a UTF-8 text format built from:

- key/value pairs;
- scalar values;
- arrays;
- tables;
- inline tables;
- arrays of tables.

A TOML document maps naturally to nested dictionaries, lists, and typed scalar values.

Example:

```toml
name = "torkit"
enabled = true
retry_count = 3

[server]
host = "127.0.0.1"
port = 8080
```

Conceptual Python result:

```python
{
    "name": "torkit",
    "enabled": True,
    "retry_count": 3,
    "server": {
        "host": "127.0.0.1",
        "port": 8080,
    },
}
```

TOML does **not** decide what `server.port` means. The program reading the document assigns that meaning.

This distinction is fundamental for `pyproject.toml`:

```text
TOML parser
    understands tables, arrays, strings, numbers

Packaging standards
    define [build-system], [project], [project.scripts]

Hatchling
    defines [tool.hatch....]

pytest
    defines [tool.pytest.ini_options]
```

A line can be valid TOML yet invalid for the consuming tool.

---

## 3. Historical context and alternatives

### INI files

INI-style configuration predates TOML and is common in operating-system and application settings.

```ini
[server]
host = 127.0.0.1
port = 8080
```

Advantages:

- simple;
- familiar;
- widely supported.

Limitations:

- weakly standardized semantics;
- values are often treated as strings;
- nested data and arrays vary by parser;
- duplicate handling differs among implementations.

TOML resembles INI visually but defines a richer and stricter data model.

### JSON

```json
{
  "server": {
    "host": "127.0.0.1",
    "port": 8080
  }
}
```

Advantages:

- extremely common;
- simple data model;
- excellent machine interchange;
- strict parser behavior.

Limitations for hand-edited configuration:

- comments are not part of standard JSON;
- every key requires quotes;
- trailing commas are invalid;
- large configuration files can become visually noisy.

JSON is excellent for APIs and generated data. TOML is often more comfortable for project configuration.

### YAML

```yaml
server:
  host: 127.0.0.1
  port: 8080
```

Advantages:

- expressive;
- concise nested structures;
- multiline text and references;
- common in infrastructure tooling.

Risks and costs:

- indentation is structural;
- implicit typing has historically surprised users;
- the full specification is large;
- parser safety and supported feature subsets require attention;
- visually similar text can have different semantics.

YAML is useful when its extra expressiveness is needed. TOML intentionally offers fewer features and more obvious scalar syntax.

### Executable Python configuration

```python
project = {
    "name": compute_name(),
    "version": read_version_from_git(),
}
```

Advantages:

- unlimited logic;
- reuse of language features;
- dynamic calculation.

Limitations:

- metadata inspection executes code;
- reproducibility depends on runtime state;
- other languages need a Python interpreter;
- security review is more difficult;
- build bootstrapping becomes circular.

Modern Python packaging moved important metadata into declarative TOML partly to avoid these problems.

### XML

XML provides schemas, namespaces, mixed content, and mature tooling. It is valuable for document interchange and heavily standardized systems. For small project configuration it is often more verbose than necessary.

---

## 4. Basic key/value syntax

A key/value pair has the form:

```toml
key = value
```

Whitespace around `=` is ignored:

```toml
name="torkit"
name = "torkit"
```

The second form is easier to read and is conventional.

### Bare keys

Bare keys may contain ASCII letters, digits, underscores, and hyphens:

```toml
name = "torkit"
requires-python = ">=3.11"
build_backend = "hatchling.build"
```

A bare key with a hyphen is still one key. It does not mean subtraction.

### Quoted keys

Keys containing other characters can be quoted:

```toml
"display name" = "TorKit"
"127.0.0.1" = "loopback"
```

Quoted keys are uncommon in `pyproject.toml` but legal.

### Comments

A `#` begins a comment unless it occurs inside a string:

```toml
name = "torkit"  # distribution name
fragment = "#not-a-comment"
```

Comments should explain intent or constraints, not repeat the key.

Weak:

```toml
version = "0.1.0"  # version
```

Useful:

```toml
requires-python = ">=3.11"  # Match the oldest interpreter used in CI.
```

---

## 5. String types

TOML has basic strings and literal strings, each with single-line and multiline forms.

### Basic strings

Double quotes support escapes:

```toml
message = "TorKit\nDevelopment"
path = "C:\\Users\\student\\torKit"
quote = "He said \"start\"."
```

### Literal strings

Single quotes do not process escapes:

```toml
windows_path = 'C:\Users\student\torKit'
regex = '\d{2}-\d{2}'
```

Literal strings are useful for backslash-heavy content. They cannot contain a single quote in the same flexible way as a basic string.

### Multiline basic strings

```toml
description = """
TorKit is a modular toolkit for building
Tor-based applications.
"""
```

Escape processing still applies.

### Multiline literal strings

```toml
example = '''
No escape processing occurs here:
C:\temp\torkit
'''
```

### Strings are not automatic versions or constraints

```toml
version = "0.1.0"
requires-python = ">=3.11"
```

TOML sees two strings. Packaging standards interpret one as a version and the other as a version specifier. A TOML parser alone will not validate packaging semantics.

---

## 6. Numbers and booleans

### Integers

```toml
port = 8080
retry_count = 3
large_value = 1_000_000
hex_mask = 0xFF
```

Underscores improve readability and do not change the value.

### Floating-point numbers

```toml
timeout = 2.5
ratio = 1e-3
```

Configuration involving money or exact decimal arithmetic should not assume binary floating point is exact. The consuming application decides whether to use `Decimal`, integer minor units, or another representation.

### Booleans

```toml
enabled = true
verbose = false
```

The valid values are lowercase `true` and `false`.

Invalid:

```toml
enabled = True
verbose = FALSE
```

### No null value

TOML has no general `null`, `nil`, or `None` literal.

This is invalid:

```toml
proxy = null
```

Absence is normally represented by omitting the key. The consuming application must define defaults and distinguish omitted values from explicitly empty strings or arrays.

---

## 7. Date and time values

TOML supports typed date and time values:

```toml
release_date = 2026-08-01
local_time = 09:30:00
local_datetime = 2026-08-01T09:30:00
offset_datetime = 2026-08-01T09:30:00-04:00
```

A compliant parser can return language-native date/time objects rather than strings.

This matters because quoting changes the type:

```toml
first = 2026-08-01
second = "2026-08-01"
```

`first` is a local date value. `second` is a string.

TorKit's current `pyproject.toml` does not use date/time values, but future operational configuration might. Time zones should be explicit for events that represent an actual instant.

---

## 8. Arrays

Arrays use brackets and commas:

```toml
dependencies = ["stem>=1.8", "waitress>=3"]
ports = [8080, 8081, 8082]
flags = [true, false, true]
```

Arrays may span lines and may have a trailing comma:

```toml
dependencies = [
    "stem>=1.8",
    "waitress>=3",
]
```

This style produces cleaner Git diffs because adding an item changes one line.

### Array element types

TOML permits arrays containing different value types, but many consuming schemas require homogeneous content.

Valid TOML:

```toml
mixed = [1, "two", true]
```

Likely invalid packaging configuration:

```toml
dependencies = ["stem", 42]
```

Again, syntax validity and application validity differ.

### TorKit example

```toml
dependencies = []
```

This is an empty array, not a missing key. Packaging tools interpret it as an explicit declaration that the project currently has no required runtime dependencies.

---

## 9. Tables

A table header opens a mapping:

```toml
[project]
name = "torkit"
version = "0.1.0"
```

Conceptually:

```python
{
    "project": {
        "name": "torkit",
        "version": "0.1.0",
    }
}
```

A later table header changes the current table:

```toml
[project]
name = "torkit"

[build-system]
requires = ["hatchling"]
```

The `requires` key belongs to `build-system`, not `project`.

### Nested tables

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

This represents nested keys:

```python
{
    "tool": {
        "pytest": {
            "ini_options": {
                "testpaths": ["tests"],
                "pythonpath": ["src"],
            }
        }
    }
}
```

The dots in a table header create nested structure.

### Tables cannot be redefined

Invalid:

```toml
[project]
name = "torkit"

[project]
version = "0.1.0"
```

Combine the keys under one table header.

### Order and meaning

TOML retains document order for human presentation, but a consumer should generally use keys by name. The packaging standard does not require `[build-system]` to appear before `[project]`; that order is chosen for readability.

---

## 10. Dotted keys

Dotted keys create nested structure without a separate table header:

```toml
server.host = "127.0.0.1"
server.port = 8080
```

Equivalent structure:

```toml
[server]
host = "127.0.0.1"
port = 8080
```

They are useful for compact configuration but can become confusing when mixed with table declarations.

Invalid redefinition pattern:

```toml
server.host = "127.0.0.1"

[server]
host = "0.0.0.0"
```

The key has already been defined.

TorKit uses dotted table names rather than dotted assignment keys:

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/torkit"]
```

This is readable because the table contains related settings and may grow later.

---

## 11. Inline tables

Inline tables use braces:

```toml
author = { name = "Brent Dean" }
```

TorKit uses an array containing one inline table:

```toml
authors = [
    { name = "Brent Dean" }
]
```

Conceptual Python value:

```python
[
    {"name": "Brent Dean"}
]
```

Inline tables are meant to remain compact and self-contained. For larger structures, use normal tables or arrays of tables.

Potential future form:

```toml
authors = [
    { name = "Brent Dean", email = "example@example.com" },
]
```

Do not invent an email address in real metadata. This only demonstrates syntax.

### No trailing comma in an inline table

Invalid:

```toml
author = { name = "Brent Dean", }
```

The surrounding array may use a trailing comma; the inline table itself may not.

---

## 12. Arrays of tables

Repeated `[[header]]` syntax creates a list of tables:

```toml
[[servers]]
name = "development"
host = "127.0.0.1"
port = 8080

[[servers]]
name = "test"
host = "127.0.0.1"
port = 8081
```

Conceptual result:

```python
{
    "servers": [
        {"name": "development", "host": "127.0.0.1", "port": 8080},
        {"name": "test", "host": "127.0.0.1", "port": 8081},
    ]
}
```

This is different from a normal table. A normal table creates one mapping; an array of tables creates a list of mappings.

TorKit's current file does not need arrays of tables. They are included here because they are a major part of TOML and may appear in future tool configuration.

---

## 13. Parsing TOML with Python

Python 3.11 added `tomllib` to the standard library for reading TOML.

```python
from pathlib import Path
import tomllib

with Path("pyproject.toml").open("rb") as source:
    configuration = tomllib.load(source)

print(configuration["project"]["name"])
```

Why binary mode?

`tomllib.load()` expects a binary file object so the parser controls UTF-8 decoding according to the TOML specification.

### Parse a string

```python
import tomllib

configuration = tomllib.loads('name = "torkit"')
print(configuration)
```

### `tomllib` reads but does not write

The standard library module intentionally provides parsing, not serialization. Writing while preserving comments and formatting is a different problem. Third-party libraries offer writing and round-trip editing.

For a build tool or validation script, reading is often enough. For an application settings editor, choose a writer deliberately and test whether comments and formatting are preserved.

### Inspect TorKit tables

```bash
python - <<'PY'
from pathlib import Path
import tomllib

with Path("pyproject.toml").open("rb") as source:
    data = tomllib.load(source)

for top_level_key, value in data.items():
    print(top_level_key, type(value).__name__)
PY
```

Expected top-level keys:

```text
build-system dict
project dict
tool dict
```

`project.scripts` is nested inside `project`; it is not a fourth top-level key.

---

## 14. TorKit's file as a hierarchy

The current file can be visualized as:

```text
pyproject.toml
├── build-system
│   ├── requires = ["hatchling"]
│   └── build-backend = "hatchling.build"
│
├── project
│   ├── name = "torkit"
│   ├── version = "0.1.0"
│   ├── description = "A modular toolkit for building Tor-based applications."
│   ├── readme = "README.md"
│   ├── requires-python = ">=3.11"
│   ├── license = "GPL-3.0-or-later"
│   ├── authors
│   │   └── [ { name = "Brent Dean" } ]
│   ├── dependencies = []
│   └── scripts
│       └── torkit = "torkit.cli:main"
│
└── tool
    ├── hatch
    │   └── build
    │       └── targets
    │           └── wheel
    │               └── packages = ["src/torkit"]
    └── pytest
        └── ini_options
            ├── testpaths = ["tests"]
            └── pythonpath = ["src"]
```

This tree clarifies a subtle point:

```toml
[project.scripts]
```

is a subtable of `project`. It does not end the `[project]` object and create an unrelated namespace.

Similarly:

```toml
[tool.hatch.build.targets.wheel]
```

is several nested tables expressed in one header.

---

## 15. Tool namespaces and ownership

The `[tool]` table is a shared namespace. Each tool owns its own subtable.

```toml
[tool.pytest.ini_options]
```

pytest defines the keys under this path.

```toml
[tool.hatch.build.targets.wheel]
```

Hatch/Hatchling defines the keys under this path.

A TOML parser accepts arbitrary keys:

```toml
[tool.pytest.ini_options]
banana = "unexpected"
```

Whether pytest ignores, warns about, or rejects that key depends on pytest. The parser cannot know.

### Why one file can serve many tools

Before `pyproject.toml`, projects often accumulated configuration files:

```text
setup.cfg
pytest.ini
tox.ini
.coveragerc
mypy.ini
.flake8
```

A shared TOML file can reduce clutter while keeping namespaces separate. It does not require every tool to use the file, and it does not make all tool schemas consistent.

### Do not move settings merely for aesthetics

A tool may not support `pyproject.toml`, may use a specific subtable, or may interpret values differently from an older INI file. Configuration migration should be tested, not performed solely to reduce file count.

---

## 16. Valid TOML versus valid `pyproject.toml`

Consider:

```toml
[project]
name = 42
```

This is syntactically valid TOML. It produces an integer. It is invalid project metadata because the project name must be a string with packaging-defined constraints.

Another example:

```toml
[build-system]
requires = "hatchling"
```

Valid TOML, wrong schema: `requires` must be an array of dependency strings.

And:

```toml
[project.scripts]
torkit = "missing.module:main"
```

Valid TOML and plausibly valid metadata syntax, but the installed command fails at runtime because the target cannot be imported.

Validation occurs in layers:

```text
Layer 1: UTF-8 and TOML grammar
Layer 2: pyproject table schemas
Layer 3: tool-specific validation
Layer 4: referenced files and import targets
Layer 5: runtime behavior
```

When debugging, identify the layer before changing syntax.

---

## 17. Common mistakes

### Mistake 1: Omitting quotes around strings

Invalid:

```toml
name = torkit
```

TOML does not treat arbitrary bare words as string values.

### Mistake 2: Using Python booleans

Invalid:

```toml
enabled = True
```

Use lowercase:

```toml
enabled = true
```

### Mistake 3: Defining the same key twice

Invalid:

```toml
version = "0.1.0"
version = "0.2.0"
```

TOML rejects duplicates rather than silently choosing one.

### Mistake 4: Reopening a table

Invalid:

```toml
[project]
name = "torkit"

[project]
version = "0.1.0"
```

### Mistake 5: Forgetting the current table

```toml
[project]
name = "torkit"

[project.scripts]
torkit = "torkit.cli:main"
version = "0.1.0"
```

Here, `version` belongs to `project.scripts`, not `project`. Table headers remain active until another header appears or the document ends.

### Mistake 6: Treating every path as a filesystem path

```toml
torkit = "torkit.cli:main"
```

This is an import-object reference defined by packaging metadata, not a filesystem path.

```toml
packages = ["src/torkit"]
```

This is a repository-relative package path interpreted by Hatchling.

The same TOML string type can represent different domain concepts.

### Mistake 7: Mixing arrays and inline tables incorrectly

Correct:

```toml
authors = [
    { name = "Brent Dean" }
]
```

Incorrect:

```toml
authors = {
    { name = "Brent Dean" }
}
```

### Mistake 8: Assuming comments become metadata

Comments are ignored by consumers. A requirement that tools must enforce belongs in a real key or validation rule, not only in prose.

### Mistake 9: Using a string when a date is intended—or the reverse

Quoted and unquoted dates have different types.

### Mistake 10: Editing generated TOML without preserving formatting

A generic parse-and-write cycle may reorder keys or remove comments. Use a round-trip library when preserving human-authored layout matters.

---

## 18. TorKit and future application configuration

`pyproject.toml` is project/build configuration, not automatically the correct place for runtime user settings.

A future TorKit runtime configuration might include:

- Tor control connection settings;
- local bind addresses;
- default download directories;
- logging preferences;
- desktop preferences;
- mode-specific defaults.

Before choosing TOML, the project should answer:

- Is the file written by humans, the application, or both?
- Must comments survive application updates?
- Are secrets stored separately?
- Does the configuration need schema migration?
- Are per-user and system-wide layers required?
- How are defaults and missing values distinguished?
- Can untrusted values cause unsafe binding or file access?

TOML can represent the data, but it does not solve validation, migration, permissions, or secret handling.

### Example only

```toml
[network]
bind_host = "127.0.0.1"
port = 0

[logging]
level = "INFO"

[share]
auto_stop = true
```

A secure application would still validate that `bind_host` follows policy, that `port` is in range, and that the file permissions are appropriate.

---

## 19. How OnionShare relates to TOML

Upstream OnionShare has used Python project tooling and `pyproject.toml` as its packaging configuration evolved. The broader lesson is not that TorKit must copy upstream's exact keys. It is that a large Python application needs a declarative center for build metadata and tool configuration while platform packaging remains a separate concern.

TorKit's upstream study also emphasizes understanding before rewriting. The same rule applies to configuration: do not copy a `[tool.*]` section without identifying the tool that owns it and the behavior it controls.

A configuration line is not self-explanatory merely because it is readable. For example:

```toml
pythonpath = ["src"]
```

looks obvious, but its meaning comes from pytest's configuration rules. Another tool could use the same key differently or not recognize it at all.

---

## 20. Laboratory exercises

### Exercise 1: Parse TorKit's file

```bash
python - <<'PY'
from pathlib import Path
import pprint
import tomllib

with Path("pyproject.toml").open("rb") as source:
    data = tomllib.load(source)

pprint.pp(data)
PY
```

Compare the nested output with the source file.

### Exercise 2: Print selected values

Write a script that prints:

- build backend;
- project name;
- minimum Python constraint;
- console-script target;
- wheel package path;
- pytest test path.

Use direct dictionary indexing first, then rewrite it with careful error messages.

### Exercise 3: Distinguish types

Parse:

```toml
date_value = 2026-08-01
string_value = "2026-08-01"
integer_value = 3
float_value = 3.0
```

Print each Python type.

### Exercise 4: Trigger a duplicate-key error

Create a temporary TOML string containing the same key twice and parse it with `tomllib.loads()`. Read the exception message.

### Exercise 5: Trigger a schema error

In a disposable copy of `pyproject.toml`, change:

```toml
requires = ["hatchling"]
```

to:

```toml
requires = "hatchling"
```

Confirm that TOML parsing succeeds. Then attempt a build and observe the packaging-layer failure. Revert the change.

### Exercise 6: Observe table scope

Parse this document and explain where `version` lands:

```toml
[project]
name = "torkit"

[project.scripts]
torkit = "torkit.cli:main"
version = "0.1.0"
```

### Exercise 7: Rewrite an inline table

Convert:

```toml
authors = [{ name = "Brent Dean" }]
```

into a multiline array with equivalent meaning. Then model two authors without changing the data shape.

### Exercise 8: Compare formats

Represent the TorKit `[project]` data in:

- TOML;
- JSON;
- YAML;
- a Python dictionary.

Compare quoting, comments, data types, and nesting.

### Exercise 9: Design a validator

Write a Python function that receives parsed data and verifies:

- `project.name` is a nonempty string;
- `project.dependencies` is a list of strings;
- `project.scripts.torkit` equals `torkit.cli:main`;
- the configured wheel package directory exists.

This demonstrates the boundary between parsing and domain validation.

### Exercise 10: Classify ownership

For every table in TorKit's file, label its owner as:

- TOML specification;
- Python packaging standard;
- Hatchling;
- pytest.

Explain why “TOML owns the table” is not a sufficient answer.

---

## 21. Review questions

1. What problem does TOML solve that executable Python configuration does not?
2. Why can a file be valid TOML but invalid `pyproject.toml`?
3. What is the difference between `[project.scripts]` and a top-level `scripts` table?
4. Why does `authors` use an array containing an inline table?
5. What is the Python type of an unquoted TOML date?
6. How does TOML represent an intentionally absent value?
7. Which tool defines `packages = ["src/torkit"]`?
8. Why are duplicate keys errors instead of last-value-wins overrides?
9. What does `tomllib` preserve, and what does it not provide?
10. Why should runtime TorKit settings not automatically be added to `pyproject.toml`?

---

## 22. Further reading and primary sources

- TOML v1.0.0 specification: <https://toml.io/en/v1.0.0>
- Python `tomllib`: <https://docs.python.org/3/library/tomllib.html>
- Python Packaging User Guide, writing `pyproject.toml`: <https://packaging.python.org/en/latest/guides/writing-pyproject-toml/>
- `pyproject.toml` specification: <https://packaging.python.org/en/latest/specifications/pyproject-toml/>
- PEP 518: <https://peps.python.org/pep-0518/>
- PEP 621: <https://peps.python.org/pep-0621/>
- Hatch build configuration: <https://hatch.pypa.io/latest/config/build/>
- pytest configuration: <https://docs.pytest.org/en/stable/reference/customize.html>
- TorKit packaging file: `pyproject.toml`

---

## Chapter summary

TOML is a declarative data format designed to be readable by humans and unambiguous to parsers. It supplies strings, numbers, booleans, dates, arrays, tables, inline tables, and arrays of tables, but it deliberately does not supply executable logic.

TorKit's `pyproject.toml` demonstrates how one TOML document can contain several schemas at once. Packaging standards define the project and build tables, Hatchling defines its wheel settings, and pytest defines test-runner options. Correct configuration therefore requires two kinds of understanding: TOML grammar and the domain rules of each consuming tool.
