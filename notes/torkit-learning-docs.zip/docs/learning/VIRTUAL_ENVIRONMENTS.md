# Python Virtual Environments: Isolating TorKit from the System

> Repository snapshot used by this chapter: `BrentDean/torKit`, `main`, 2026-08-01.
>
> A virtual environment is not a virtual machine and not a container. It is a project-scoped Python installation context that controls which interpreter, packages, metadata, and console scripts a shell uses. This chapter explains why that boundary exists and how it supports a reliable TorKit development workflow.

## Learning goals

After completing this chapter, you should be able to:

- explain the dependency-conflict problem virtual environments solve;
- describe what `python -m venv .venv` creates;
- explain what activation changes and what it does not change;
- distinguish a virtual environment from pyenv, pipx, Conda, containers, and virtual machines;
- install TorKit editable into the intended environment;
- verify which interpreter, pip, package, and command are active;
- explain why virtual environments are disposable and should not be committed;
- recover from a stale, copied, moved, or incorrectly selected environment;
- design a repeatable TorKit setup and teardown procedure.

---

## 1. The historical dependency conflict

Suppose one machine runs two Python applications:

```text
Application A needs library X version 1
Application B needs library X version 2
```

A single global package directory cannot make both versions active for the same interpreter at the same time.

```text
/usr/lib/python/site-packages/
└── library_x/
    └── one installed version
```

Installing version 2 may break Application A. Reinstalling version 1 may break Application B.

This is not a rare edge case. Applications often require different versions because:

- an API changed;
- a security fix requires an upgrade;
- an old application has not been migrated;
- one project tests a development version;
- operating-system tools depend on distribution-managed Python packages;
- native extensions are compiled for a specific interpreter.

The solution is to give each project an isolated package installation area.

```text
base Python installation
       │
       ├── Project A environment
       │      └── library X 1.x
       │
       └── Project B environment
              └── library X 2.x
```

Python's standard `venv` module creates this boundary.

---

## 2. What a virtual environment is

A virtual environment is a directory associated with a base Python interpreter and containing an independent package installation location.

Typical TorKit environment:

```text
torKit/
├── .venv/
│   ├── bin/ or Scripts/
│   ├── include/
│   ├── lib/
│   └── pyvenv.cfg
├── docs/
├── src/
├── tests/
└── pyproject.toml
```

On Unix-like systems:

```text
.venv/bin/python
.venv/bin/pip
.venv/bin/activate
.venv/lib/python3.x/site-packages/
```

On Windows:

```text
.venv\Scripts\python.exe
.venv\Scripts\pip.exe
.venv\Scripts\Activate.ps1
.venv\Lib\site-packages\
```

The environment normally uses the base interpreter's Python installation while changing prefix and package search behavior. Implementations may use copies or links for executable files depending on platform and options.

### What it isolates

A virtual environment primarily isolates:

- Python package installations;
- distribution metadata;
- generated console scripts;
- interpreter prefix information;
- commands discovered through the activated environment's executable directory.

### What it does not isolate

It does not create strong operating-system isolation for:

- processes;
- network interfaces;
- files outside the environment;
- users and permissions;
- kernel resources;
- system libraries;
- environment variables generally;
- Tor processes or web servers launched by the application.

A virtual environment is a packaging boundary, not a security sandbox.

---

## 3. Creating TorKit's environment

From the repository root:

```bash
python3 -m venv .venv
```

Using `-m venv` means “run the standard-library `venv` module with this interpreter.” The resulting environment is based on the `python3` selected by the shell.

Verify the base interpreter first:

```bash
python3 --version
command -v python3
```

TorKit currently declares:

```toml
requires-python = ">=3.11"
```

Therefore the selected interpreter must be Python 3.11 or newer.

### Choose the interpreter deliberately

If several versions are installed:

```bash
python3.11 -m venv .venv
```

or:

```bash
python3.13 -m venv .venv
```

The environment does not automatically upgrade when the system gains a newer Python. Recreate it with the desired interpreter.

### Why `.venv` is a useful name

- the leading dot keeps it visually unobtrusive on Unix-like systems;
- editors commonly detect it;
- it clearly belongs to the project;
- it differs from `.env`, which often means a text file of environment variables;
- commands can be documented consistently.

The name is a convention, not a requirement.

---

## 4. Activation

On Bash or Zsh:

```bash
source .venv/bin/activate
```

On Fish:

```fish
source .venv/bin/activate.fish
```

On Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Activation usually:

- prepends the environment's executable directory to `PATH`;
- sets `VIRTUAL_ENV`;
- changes the shell prompt;
- defines a `deactivate` shell function;
- preserves enough previous shell state to reverse those changes.

Conceptually:

```text
Before activation PATH:
/usr/local/bin:/usr/bin:/bin

After activation PATH:
/project/.venv/bin:/usr/local/bin:/usr/bin:/bin
```

Now `python`, `pip`, and generated commands are found in `.venv/bin` first.

### Activation does not start the environment

A virtual environment is not a service. Nothing runs in the background. Activation changes shell command resolution.

### Activation is optional

You can address the interpreter directly:

```bash
.venv/bin/python -m pip install -e .
.venv/bin/python -m pytest
.venv/bin/torkit
```

This is useful in scripts because it avoids depending on shell activation state.

### Activation is shell-local

Activating in one terminal does not activate another terminal. Subprocesses inherit environment variables and `PATH`, but unrelated shells do not.

---

## 5. Installing TorKit into the environment

After activation:

```bash
python -m pip install -e .
```

This performs several actions:

- reads `pyproject.toml`;
- obtains the Hatchling build backend as needed;
- installs project metadata;
- makes `src/torkit` importable in editable mode;
- creates the `torkit` console script;
- installs declared runtime dependencies, which are currently empty.

The environment now connects the repository source to the installed command:

```text
.venv/bin/torkit
       │
       ▼
entry-point metadata
       │
       ▼
torkit.cli:main
       │
       ▼
repository/src/torkit/cli.py
```

Run:

```bash
torkit
```

Expected output:

```text
TorKit
```

### Why editable mode belongs in a development environment

You want source edits to affect the next process without copying package files after every change. You also want project metadata and commands installed in the same form expected by users.

A normal installation is more appropriate when testing a built artifact:

```bash
python -m pip install dist/torkit-0.1.0-py3-none-any.whl
```

---

## 6. Verify the active environment instead of trusting the prompt

A prompt such as `(.venv)` is helpful but not authoritative. Verify the actual command paths.

```bash
command -v python
command -v pip
command -v torkit
python --version
python -m pip --version
```

Expected paths should begin with the project environment directory.

Inspect Python's prefixes:

```bash
python - <<'PY'
import sys

print("executable:", sys.executable)
print("prefix:", sys.prefix)
print("base prefix:", sys.base_prefix)
print("in virtual environment:", sys.prefix != sys.base_prefix)
PY
```

In a typical virtual environment:

```text
sys.prefix != sys.base_prefix
```

Locate TorKit:

```bash
python - <<'PY'
import torkit

print(torkit.__file__)
PY
```

For an editable install, the path should normally lead to the repository's `src/torkit/__init__.py` or an editable import mechanism associated with it.

Show installed metadata:

```bash
python -m pip show torkit
```

---

## 7. Deactivation

Run:

```bash
deactivate
```

This restores the shell's previous `PATH` and prompt state.

It does not:

- uninstall packages;
- delete `.venv`;
- stop TorKit processes already launched;
- revert source changes;
- remove environment files.

The environment remains available for later activation.

---

## 8. Virtual environments are disposable

The environment directory should be reproducible from project configuration and setup commands. It should not contain project source or irreplaceable information.

```text
source of truth                         generated local state
---------------                         ---------------------
pyproject.toml                          .venv/
lock/constraint files if adopted        installed packages
source code                             generated scripts
setup instructions                      caches
```

If the environment is corrupted or confusing:

```bash
deactivate 2>/dev/null || true
rm -rf .venv
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

Recreation is often safer than attempting to repair a deeply stale environment package by package.

### Do not commit `.venv`

Reasons:

- absolute paths may be embedded in scripts and configuration;
- platform-specific binaries may be present;
- the directory can be large;
- it contains generated state;
- it may include packages for one OS and architecture;
- moving or cloning it does not create a reliable environment;
- it creates noisy, unnecessary Git history.

Add an appropriate ignore rule if one does not already exist:

```gitignore
.venv/
```

This chapter does not modify TorKit's ignore configuration; it explains the intended rule.

---

## 9. Why environments are not movable

A common mistake is to copy `.venv` to another directory or machine.

Generated console scripts often contain an interpreter path. A Unix script may begin with a shebang similar to:

```text
#!/old/path/to/torKit/.venv/bin/python
```

After moving the repository, that path is wrong.

Other files may encode:

- environment prefixes;
- compiled extension paths;
- platform tags;
- interpreter ABI expectations;
- native library search behavior.

The correct migration process is:

```text
copy/clone source and configuration
              │
              ▼
create a new virtual environment
              │
              ▼
install dependencies and project
```

Do not treat `.venv` as a deployable artifact.

---

## 10. The relationship between `venv`, pip, and packaging

These tools solve different problems.

```text
venv
  creates an isolated Python environment

pip
  installs distributions into an environment

pyproject.toml
  describes how the project is built and installed

Hatchling
  builds TorKit according to project configuration
```

Creating the environment does not install TorKit:

```bash
python3 -m venv .venv
```

Installing TorKit does not create a new environment automatically:

```bash
python -m pip install -e .
```

The normal sequence is:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

### Why `python -m pip` matters again

Within a selected environment:

```bash
python -m pip --version
```

shows both the pip installation and interpreter context. A bare `pip` may resolve unexpectedly if `PATH` is stale or activation failed.

---

## 11. System Python and externally managed environments

Linux distributions may use Python for operating-system tools and package-management scripts. Installing arbitrary packages into that interpreter can conflict with files owned by the distribution.

Modern Python packaging includes the concept of an **externally managed environment**, where pip may refuse unsafe global installation and direct users toward virtual environments or OS package managers.

This is protective behavior, not a packaging failure.

Do not solve it with indiscriminate force flags or `sudo pip install`. Create a project environment.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

TorKit development should not alter the system Python package set.

---

## 12. Alternatives and adjacent tools

### `virtualenv`

`virtualenv` is a third-party environment creator that predates `venv` and provides additional compatibility and features. For modern Python, standard `venv` is often sufficient.

### pyenv

pyenv selects among installed Python interpreter versions.

```text
pyenv answers: Which base Python executable?
venv answers: Which isolated package environment?
```

They are complementary:

```bash
pyenv local 3.13.5
python -m venv .venv
```

### Conda

Conda manages environments and packages, including non-Python native libraries. It is valuable in scientific and cross-language stacks. Its package ecosystem and environment model are broader than `venv` plus pip.

### Poetry, PDM, Hatch, and uv

These tools can create or manage environments as part of a larger project workflow. They may also resolve dependencies, maintain lock files, run scripts, and build packages.

Using such a tool does not eliminate the underlying concepts. You still need to know:

- which interpreter is selected;
- where packages are installed;
- whether TorKit is editable;
- how the command is generated;
- what configuration is authoritative.

### pipx

pipx installs Python command-line applications into isolated environments and exposes their commands globally.

It is useful for **using** tools such as `black`, `ruff`, or possibly a released TorKit CLI. It is not the usual mechanism for actively editing TorKit's source tree.

### Containers

A container isolates a process filesystem and other operating-system resources more broadly. A container image may still contain a Python virtual environment, though many container workflows install directly into the image's dedicated Python context.

Containers solve deployment and runtime isolation problems that `venv` does not.

### Virtual machines

A VM runs a separate operating-system kernel and userland. It is far heavier but provides a much stronger machine boundary.

```text
venv              Python packages and command paths
container         process/filesystem/network namespaces and image
virtual machine   separate guest operating system and kernel boundary
```

---

## 13. Site-packages, scripts, and installation records

A virtual environment is useful because Python and packaging tools agree on several environment-specific locations.

Inspect them:

```bash
python - <<'PY'
import sysconfig

for name in ("purelib", "platlib", "scripts", "include", "data"):
    print(f"{name:8} {sysconfig.get_path(name)}")
PY
```

Typical meanings:

- `purelib` — pure-Python installed packages;
- `platlib` — platform-specific packages, often the same directory in a virtual environment;
- `scripts` — generated commands such as `torkit` and `pytest`;
- `include` — headers used when building extension modules;
- `data` — environment-relative data installation prefix.

When pip installs a distribution, it also installs metadata under a directory ending in `.dist-info`:

```text
.venv/lib/python3.x/site-packages/
├── torkit editable linkage or package files
└── torkit-0.1.0.dist-info/
    ├── METADATA
    ├── RECORD
    ├── entry_points.txt
    └── other installation metadata
```

`RECORD` describes installed files for a normal wheel installation. Entry-point metadata tells installers which command wrappers to generate. This is why deleting only the imported package directory is not a correct uninstall procedure. Use:

```bash
python -m pip uninstall torkit
```

The installer can then use its metadata to remove the distribution coherently.

### Environment packages are interpreter-specific

A package installed under Python 3.11's environment is not automatically installed for Python 3.13. Even pure-Python packages live under an interpreter-specific environment prefix. Native extensions may also be compiled for a particular Python ABI.

This is one reason the correct question is not merely “Is Stem installed?” It is:

> Is the required distribution installed in the environment used by this exact Python process?

Check from that interpreter:

```bash
python -m pip show stem
python -c 'import stem; print(stem.__file__)'
```

---

## 14. Reproducing dependencies without copying the environment

A disposable environment is useful only when its contents can be recreated.

TorKit currently has no runtime dependencies:

```toml
dependencies = []
```

As the project grows, the authoritative inputs may include:

- dependency declarations in `pyproject.toml`;
- optional dependency groups;
- a lock file selected by project policy;
- operating-system prerequisites;
- locally cached artifacts for offline installation;
- documented Python-version constraints.

### `pip freeze` is an observation, not always a design

```bash
python -m pip freeze
```

prints installed distributions and versions. This is useful for diagnostics, but blindly using the output as project dependency design can capture:

- transitive dependencies that should not be declared directly;
- unrelated tools installed for the developer;
- editable local paths;
- platform-specific packages;
- accidental packages that the project does not use.

A requirements snapshot answers “What is installed here?” Project metadata answers “What does this project require?” A lock file answers “What exact resolution should this application reproduce under defined conditions?”

Those are related but different questions.

### Rebuild test

A useful reliability check is:

```text
new empty environment
        │
        ▼
install from declared project inputs only
        │
        ▼
run tests and package checks
```

If the build succeeds only in a long-lived developer environment, an undeclared dependency may exist.

---

## 15. Native libraries and the boundary of `venv`

A Python package can depend on software outside the virtual environment.

Examples include:

- a Tor executable;
- OpenSSL or other shared libraries;
- C compilers and headers used during a source build;
- Qt platform plugins;
- operating-system certificate stores;
- browser binaries used by test automation.

A virtual environment may isolate the Python wrapper while still relying on the host:

```text
TorKit Python package in .venv
            │
            ├── imports Python dependencies from .venv
            ├── launches /usr/bin/tor
            ├── loads host shared libraries
            └── reads host filesystem and configuration
```

This means “the virtual environment installs successfully” is not the same as “the complete application runtime is portable.”

For TorKit, the eventual development guide must identify which dependencies are:

```text
Python distributions
host executables
native shared libraries
build-only tools
runtime-only services
platform packaging components
```

The environment chapter should remain focused on Python isolation while linking to later technology-specific chapters for Tor, web serving, Qt, and operating-system packaging.

---

## 16. Editors, test runners, and automation

An editor may select a different interpreter from the shell. Symptoms include:

- imports work in a terminal but appear unresolved in the editor;
- tests pass from the editor but fail from the shell;
- formatting tools use different versions;
- debug sessions cannot find the `torkit` package.

Configure the editor to use:

```text
/path/to/torKit/.venv/bin/python
```

or the Windows equivalent.

Then verify from an integrated terminal or debug console:

```python
import sys
print(sys.executable)
```

### Test runners

Prefer interpreter-qualified commands:

```bash
python -m pytest
```

This guarantees that pytest is imported by the selected Python. A bare `pytest` command is normally fine after correct activation, but `python -m pytest` is easier to diagnose.

### CI environments

A continuous-integration runner normally creates a fresh environment for each job:

```text
checkout source
select Python
create or receive isolated environment
install project
run checks
discard runner
```

This disposability is a strength. It tests whether declared inputs are sufficient. CI should not upload or reuse a developer's `.venv` directory as the project artifact.

### Offline and controlled environments

For restricted networks, prepare a wheelhouse or approved package mirror:

```bash
python -m pip download --dest wheelhouse <requirements>
python -m pip install --no-index --find-links wheelhouse -e .
```

Exact commands depend on whether build requirements, editable installation, and transitive dependencies are available as local wheels. Offline design must account for Hatchling as a build requirement, not only TorKit's runtime dependencies.

---

## 17. TorKit's likely development workflow

Current minimal workflow:

```bash
cd /path/to/torKit
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
torkit
```

As tests and tools are added, the workflow may become:

```bash
python -m pip install -e '.[dev]'
python -m pytest
```

That optional dependency group does not exist yet. Documentation should describe actual configuration, not pretend future groups are already implemented.

### A repeatable shell check

```bash
printf 'python: %s\n' "$(command -v python)"
printf 'torkit: %s\n' "$(command -v torkit)"
python --version
python -m pip show torkit
python -c 'import torkit; print(torkit.__file__)'
```

This gives more useful evidence than “the prompt says `.venv`.”

---

## 18. How OnionShare uses isolated development environments

Upstream OnionShare's development instructions have used project-specific environment and dependency tooling so contributors can run the Python CLI and desktop code without polluting system packages. Historical instructions used Poetry commands, and platform-specific setup files describe dependencies for the CLI and GUI.

The exact tool can change. The enduring requirement is isolation:

- OnionShare depends on many Python and native components;
- the desktop and CLI may have different dependency surfaces;
- contributors need reproducible setup;
- system Python should remain protected;
- packaging tests should not depend on unrelated globally installed modules.

TorKit begins with a much smaller dependency set, but establishing the environment boundary now prevents accidental global coupling later.

---

## 19. Common mistakes and recovery

### Mistake 1: Creating the environment with the wrong Python

Symptom:

```text
ERROR: Package 'torkit' requires a different Python: 3.10.x not in '>=3.11'
```

Recovery:

```bash
rm -rf .venv
python3.11 -m venv .venv
```

### Mistake 2: Activating one environment and using another pip

Check:

```bash
command -v python
command -v pip
python -m pip --version
```

Prefer `python -m pip`.

### Mistake 3: Nested activation confusion

Activating environment B while environment A is active can leave the prompt and shell history confusing. Deactivate first or start a clean shell.

### Mistake 4: Copying `.venv` with the repository

Delete and recreate it at the new path.

### Mistake 5: Assuming source changes are visible in an old process

Editable installation affects future imports. A long-running Python process may keep the already imported module in `sys.modules`. Restart the command or process.

### Mistake 6: Changing entry points without reinstalling

After changing `[project.scripts]`:

```bash
python -m pip install -e .
```

### Mistake 7: Running `sudo pip install`

Do not escalate permissions to bypass environment design. Use `.venv`.

### Mistake 8: Committing the environment

Remove it from Git tracking without deleting the local directory:

```bash
git rm -r --cached .venv
```

Then add `.venv/` to `.gitignore`. Only do this if it was actually tracked.

### Mistake 9: Confusing `.env` and `.venv`

```text
.env     commonly a text file of environment-variable assignments
.venv/   Python virtual environment directory
```

Neither format automatically secures secrets.

### Mistake 10: Using activation as proof of isolation

A malicious or broken shell alias can override commands. Use `type -a python`, `command -v python`, and `sys.executable` when diagnosing.

---

## 20. Laboratory exercises

### Exercise 1: Create and inspect

```bash
python3 -m venv /tmp/torkit-venv-lab
find /tmp/torkit-venv-lab -maxdepth 2 -type f | sort | head -50
cat /tmp/torkit-venv-lab/pyvenv.cfg
```

Identify the base interpreter information and executable directory.

### Exercise 2: Compare prefixes

Run the following outside and inside the environment:

```python
import sys
print(sys.executable)
print(sys.prefix)
print(sys.base_prefix)
```

Explain each difference.

### Exercise 3: Activation versus direct invocation

Without activation:

```bash
/tmp/torkit-venv-lab/bin/python --version
```

Then activate and run:

```bash
python --version
```

Prove that activation is convenience, not a requirement.

### Exercise 4: Install TorKit editable

Inside a project environment:

```bash
python -m pip install -e .
python -m pip show torkit
torkit
```

Trace the command to `src/torkit/cli.py`.

### Exercise 5: Inspect `PATH`

Print each `PATH` entry on its own line before and after activation:

```bash
printf '%s\n' "$PATH" | tr ':' '\n'
```

Identify the inserted directory.

### Exercise 6: Demonstrate process-local imports

1. Start a Python REPL.
2. Import `torkit.cli`.
3. Temporarily edit the printed string.
4. Call the already imported function again.
5. Start a new process and compare.
6. Revert the edit.

Explain module caching.

### Exercise 7: Break relocation safely

Create a disposable environment under `/tmp/a`, install a tiny console script, move the directory to `/tmp/b`, and inspect the script's first line. Do not use the project environment for this experiment.

### Exercise 8: Compare a virtual environment and a container

List five resources a container may isolate that `venv` does not. Then list two reasons a Python environment can still be useful inside a container image.

### Exercise 9: Rebuild from scratch

Delete a disposable TorKit environment and recreate it using only documented project files and commands. Record any undeclared dependency you discover.

### Exercise 10: Write an environment diagnostic script

Produce a script that exits nonzero unless:

- Python is at least 3.11;
- the interpreter is in a virtual environment;
- TorKit is importable;
- the imported source path contains `src/torkit`;
- the `torkit` command is found.

Do not add it to the repository until its role is discussed.

---

## 21. Review questions

1. What exact conflict do virtual environments solve?
2. What does activation change in the current shell?
3. Why can you use an environment without activating it?
4. Why is `.venv` not a security sandbox?
5. Why should `.venv` be recreated rather than copied?
6. How do `sys.prefix` and `sys.base_prefix` reveal environment state?
7. What is the difference between pyenv and `venv`?
8. When is pipx more appropriate than a project editable install?
9. Why can an editable source change require a new process but not a reinstall?
10. Why should TorKit establish isolation before it has many dependencies?

---

## 22. Further reading and primary sources

- Python tutorial, virtual environments and packages: <https://docs.python.org/3/tutorial/venv.html>
- Python `venv` module: <https://docs.python.org/3/library/venv.html>
- Python Packaging User Guide, installing packages: <https://packaging.python.org/en/latest/tutorials/installing-packages/>
- Python Packaging User Guide, virtual environments: <https://packaging.python.org/en/latest/guides/installing-using-pip-and-virtual-environments/>
- PEP 405, Python virtual environments: <https://peps.python.org/pep-0405/>
- Externally managed environments specification: <https://packaging.python.org/en/latest/specifications/externally-managed-environments/>
- OnionShare development documentation: <https://docs.onionshare.org/2.6.4/en/develop.html>
- TorKit project metadata: `pyproject.toml`

---

## Chapter summary

A Python virtual environment gives TorKit an isolated package installation and command namespace tied to a chosen Python interpreter. Activation merely changes the current shell so the environment's executables are found first. The environment is neither a running service nor a security sandbox.

The reliable TorKit pattern is to select a compatible Python, create `.venv`, install the project editable, verify paths, and recreate the environment whenever its history becomes uncertain. Source and configuration belong in Git; the environment is generated local state. Understanding that boundary prevents many of the most common Python setup failures.
