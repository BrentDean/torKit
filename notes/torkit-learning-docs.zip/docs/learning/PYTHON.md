# Python: The Language Under TorKit

> Repository snapshot used by this chapter: `BrentDean/torKit`, `main`, 2026-08-01.
>
> This chapter teaches Python through the small amount of Python that TorKit already contains and through the architecture TorKit plans to build. It is not a complete language reference. Its purpose is to establish the mental models required to read, test, and extend the project correctly.

## Learning goals

After completing this chapter, you should be able to:

- explain why Python was created and why it became common in application and automation software;
- distinguish source files, modules, packages, distributions, and installed projects;
- explain what `src/torkit/__init__.py` does even though it is empty;
- read `def main() -> None:` without confusing the arrow with a JavaScript arrow function;
- explain how Python imports TorKit from the `src/` directory after installation;
- predict how names, objects, mutability, and function calls behave;
- identify which parts of TorKit should contain application logic and which should remain thin entry points;
- perform small experiments that reveal Python behavior instead of memorizing rules.

---

## 1. Why Python exists

Python did not begin as an attempt to produce the fastest possible language or the language with the smallest runtime. It began as an attempt to make programming easier to read, write, and maintain without giving up access to operating-system services.

Guido van Rossum started Python near the end of the 1980s and released it publicly in the early 1990s. Python was influenced by ABC, a teaching-oriented language whose syntax emphasized clarity. ABC was pleasant for expressing algorithms but was not designed as a practical systems integration language. Python kept the emphasis on readable structure while adding the ability to work with files, processes, networks, extension modules, and the host operating system.

That combination solved a recurring engineering problem:

```text
Low-level languages                    Shell scripts
-------------------                    -------------
Fast and close to the OS               Fast to write
Explicit memory and types              Good process composition
Large amount of ceremony               Weak structure at scale
Slow application development           Poor portability for complex programs
                 \                      /
                  \                    /
                   Python aimed here
```

Python became useful as a **glue language**. A Python program could coordinate mature components written in C or C++, expose a readable application layer, and remain portable across operating systems. Over time, the language also became a primary implementation language for web applications, scientific software, test systems, command-line tools, and desktop programs.

For TorKit, this matters because the project is not trying to implement Tor cryptography or an HTTP protocol stack from scratch. It needs to coordinate services, validate data, model application state, expose a CLI and later a GUI, and remain understandable to a learner. Python is well suited to that layer.

### Alternatives

Python is not automatically the best choice for every layer.

- **Rust** offers stronger compile-time guarantees, deterministic performance, and memory safety without a garbage collector. It also introduces a steeper type and ownership model.
- **Go** offers simple deployment and strong concurrency primitives, but its application modeling style differs substantially from Python and desktop GUI options are less mature.
- **Java or C#** provide static typing, mature tooling, and large desktop/server ecosystems, but typically require more structural ceremony.
- **JavaScript or TypeScript** are natural for browser and Node.js applications. Desktop use often involves Electron or another embedded web runtime.
- **C or C++** provide direct control and native performance, but increase memory-safety and maintenance risk for an educational application.

TorKit can still call programs or libraries written in other languages. Choosing Python for the application layer does not require every component to be implemented in Python.

---

## 2. How Python executes a program

A useful simplified model is:

```text
source text (.py)
      │
      ▼
parser creates syntax structures
      │
      ▼
compiler creates Python bytecode
      │
      ▼
Python virtual machine executes bytecode
      │
      ▼
objects are created, referenced, changed, and released
```

The common CPython implementation compiles source into bytecode and executes that bytecode in a virtual machine. This is different from compiling a C program directly into a standalone native executable, but it is also different from the simplistic claim that Python merely “reads one line at a time.”

You can inspect bytecode:

```bash
python -m dis src/torkit/cli.py
```

For TorKit's current function:

```python
def main() -> None:
    print("TorKit")
```

Python performs two separate activities when the module is imported:

1. It executes the `def` statement, creating a function object and binding it to the name `main`.
2. It does **not** execute the body of `main` until something calls the function.

That distinction becomes important when modules grow. Top-level code runs at import time; function bodies run when called.

### Import-time side effects

Consider this bad library module:

```python
print("Connecting to Tor...")
connection = start_tor()


def publish_service() -> None:
    ...
```

Any import would start Tor immediately. Tests, documentation tools, and unrelated commands could trigger a network service merely by importing a name. TorKit's architecture calls for explicit ownership and lifecycle control, so expensive or security-sensitive actions should be placed behind explicit methods such as `start()` rather than executed during import.

---

## 3. Source files, modules, and packages

These terms sound interchangeable but refer to different things.

### Module

A **module** is an importable unit of Python code. A file named `cli.py` normally defines a module.

TorKit currently contains:

```text
src/torkit/cli.py
```

After installation, its fully qualified module name is:

```text
torkit.cli
```

You can import it:

```python
import torkit.cli

torkit.cli.main()
```

Or import one name from it:

```python
from torkit.cli import main

main()
```

### Package

A **package** is a module that can contain submodules. In the regular package model, a directory containing `__init__.py` forms a package.

TorKit currently contains:

```text
src/
└── torkit/
    ├── __init__.py
    └── cli.py
```

The directory `src/torkit/` is the package directory. The file `src/torkit/__init__.py` defines package initialization behavior.

### Distribution package

A **distribution package** is the installable artifact and metadata managed by packaging tools. TorKit's distribution name is declared in `pyproject.toml`:

```toml
[project]
name = "torkit"
```

The import package and distribution package both happen to be named `torkit`, but that is a convention, not a language requirement. For example, a distribution named `beautifulsoup4` provides the import package `bs4`.

This distinction prevents a common mistake:

```text
pip installs distributions
Python imports modules and packages
```

---

## 4. What `__init__.py` actually does

TorKit's current file is empty:

```text
src/torkit/__init__.py
```

An empty file still has meaning. It marks `torkit` as a regular Python package and provides a place for package-level initialization or public exports later.

When Python evaluates:

```python
import torkit
```

it loads the package and executes `torkit/__init__.py`. Because TorKit's file is empty, importing `torkit` currently creates the package module without additional behavior.

### Why not fill it immediately?

Beginners often turn `__init__.py` into a dumping ground:

```python
from .cli import main
from .tor import TorService
from .web import WebService
from .sessions import ShareSession
from .configuration import ConfigurationService
```

This may appear convenient, but it creates several risks:

- importing `torkit` imports much of the application;
- circular imports become more likely;
- optional dependencies may become mandatory at import time;
- startup becomes harder to reason about;
- package boundaries become less visible.

An empty `__init__.py` is therefore not unfinished. It is a conservative starting point.

### When package exports are useful

A carefully designed library may expose a small stable surface:

```python
# src/torkit/__init__.py
from .application.controller import ApplicationController

__all__ = ["ApplicationController"]
```

Then users can write:

```python
from torkit import ApplicationController
```

TorKit should do this only after the public API is deliberate. Internal convenience should not be mistaken for a stable public contract.

### Namespace packages

Modern Python can also create **namespace packages** without `__init__.py`. They are useful when multiple installed distributions contribute subpackages under one shared package name. TorKit does not need that model. A regular package is simpler and more explicit.

---

## 5. Functions and the arrow in `def main() -> None`

TorKit's current CLI contains:

```python
def main() -> None:
    print("TorKit")
```

Read it from left to right:

- `def` begins a function definition.
- `main` is the function's name.
- `()` means the function declares no parameters.
- `-> None` is a return type annotation.
- `:` begins the indented function body.

The annotation says that callers should expect the function to return no meaningful value. In Python, a function that reaches the end without an explicit `return` returns the singleton object `None`.

```python
result = main()
print(result)  # None
```

### This is not a JavaScript arrow function

JavaScript:

```javascript
const add = (a, b) => a + b;
```

Python:

```python
def add(a: int, b: int) -> int:
    return a + b
```

The JavaScript `=>` participates in defining the function. Python's `->` only annotates the expected return type. The Python function would still exist without annotations:

```python
def add(a, b):
    return a + b
```

Python also has anonymous functions using `lambda`:

```python
add = lambda a, b: a + b
```

That resembles a JavaScript arrow function more closely, but Python lambdas are restricted to one expression and are normally used for small callbacks or sorting keys, not as the standard way to define named functions.

### Type annotations are not automatic runtime enforcement

This code still runs unless another tool checks it:

```python
def repeat(count: int) -> str:
    return count  # incorrect annotation, but Python itself permits the return
```

Static type checkers such as mypy or pyright can detect the mismatch. Runtime validators can also enforce types, but annotations alone are metadata.

TorKit should use annotations because they make interfaces clearer and allow tools to detect mistakes before execution. They do not replace tests or runtime validation of untrusted input.

---

## 6. Names refer to objects

A central Python mental model is:

> Variables are names bound to objects, not labeled boxes that permanently contain one primitive value.

```python
first = ["share.txt"]
second = first
second.append("notes.txt")

print(first)
# ['share.txt', 'notes.txt']
```

Both names refer to the same list object:

```text
first  ─┐
        ├──► list object ["share.txt", "notes.txt"]
second ─┘
```

Assignment did not copy the list.

### Identity and equality

```python
a = [1, 2]
b = [1, 2]
c = a

print(a == b)  # True: equal contents
print(a is b)  # False: different objects
print(a is c)  # True: same object
```

Use `==` for value comparison. Use `is` for identity, most commonly with singleton values:

```python
if result is None:
    ...
```

Do not write:

```python
if result is 0:       # wrong intention
    ...

if name is "share":  # wrong intention
    ...
```

### Mutable and immutable objects

Common immutable objects:

- integers;
- floating-point numbers;
- strings;
- bytes;
- tuples, provided their contained objects do not undermine the intended use;
- frozen data structures.

Common mutable objects:

- lists;
- dictionaries;
- sets;
- most user-defined class instances.

This affects function design. A function that receives a list can mutate the caller's object:

```python
def add_default(items: list[str]) -> None:
    items.append("README.md")
```

For security-sensitive structures such as a file allowlist, accidental mutation may be dangerous. TorKit's future models may use tuples, frozen dataclasses, or controlled methods to make ownership and modification explicit.

---

## 7. Scope and lifetime of names

Python searches names using a rule commonly summarized as LEGB:

```text
Local
Enclosing
Global (module)
Built-in
```

Example:

```python
application_name = "TorKit"  # global to this module


def show_name() -> None:
    prefix = "Application"   # local
    print(prefix, application_name)
```

A module global is global only to that module, not to the entire process in the way beginners sometimes imagine.

### Avoid global mutable application state

This design is tempting:

```python
active_sessions = []
```

Then every module imports and modifies it. That creates hidden ownership, difficult cleanup, and test interference. TorKit's architecture instead says that `SessionManager` should own active sessions. The Python implementation should express that ownership through objects passed explicitly to collaborators.

```python
class SessionManager:
    def __init__(self) -> None:
        self._active_sessions: dict[str, object] = {}
```

The underscore does not make the attribute private at runtime. It communicates that callers should treat it as an implementation detail.

---

## 8. Imports and `sys.path`

When Python executes:

```python
import torkit.cli
```

it must find the package. It searches import locations stored in `sys.path`.

```python
import sys

for path in sys.path:
    print(path)
```

Important entries may include:

- the current script's directory;
- the standard library;
- the active environment's `site-packages` directory;
- paths added by an editable installation.

TorKit uses a `src/` layout:

```text
repository root
├── pyproject.toml
├── src/
│   └── torkit/
└── tests/
```

The package is not at the repository root. This intentionally prevents Python from importing it merely because the shell happens to be in the project directory. The project is meant to be installed, normally with:

```bash
python -m pip install -e .
```

An editable installation tells the environment how to import the source package while leaving the actual code in the working tree. Editing `src/torkit/cli.py` then changes what a new Python process imports without rebuilding and copying the package after every edit.

### Why `python -m pip` is preferable to bare `pip`

```bash
python -m pip install -e .
```

uses the `pip` module belonging to the selected `python` interpreter. A bare `pip` command may belong to a different Python installation, especially on systems with multiple versions or environments.

---

## 9. Entry points and thin startup functions

TorKit's `pyproject.toml` contains:

```toml
[project.scripts]
torkit = "torkit.cli:main"
```

After installation, the build/install tooling creates a command named `torkit`. Conceptually, that generated command performs:

```python
from torkit.cli import main

raise SystemExit(main())
```

The exact wrapper is tool-generated, but the important mapping is:

```text
shell command      import module      object to call
    torkit    ───►  torkit.cli   ───►     main
```

The colon in `torkit.cli:main` is packaging entry-point syntax. It is not Python attribute syntax used directly in source code.

### Why keep `main()` thin?

A good entry point translates external process concerns into an application call:

```python
def main() -> int:
    arguments = parse_arguments()
    controller = build_application(arguments)
    return controller.run()
```

It should not become the implementation of Tor startup, web routing, file validation, transfer tracking, and GUI coordination. Thin entry points allow the CLI, GUI, tests, and future interfaces to call the same backend.

TorKit's architecture explicitly follows that rule. The current two-line `main()` is therefore a placeholder in the correct location, not the beginning of a monolithic script.

---

## 10. Control flow and indentation

Python uses indentation as syntax.

```python
def describe_state(state: str) -> str:
    if state == "running":
        return "The session is active."
    if state == "failed":
        return "The session failed."
    return "The session is not active."
```

Braces do not delimit the blocks. Consistent indentation does.

### Truth values

Python treats several values as false in conditions:

```text
False
None
0
0.0
""
[]
{}
set()
```

This is convenient but can erase distinctions:

```python
if not port:
    ...
```

That condition treats `None` and `0` the same. Sometimes that is correct; sometimes it hides an invalid value. Security- and lifecycle-sensitive code should be explicit when states have different meanings:

```python
if port is None:
    raise ConfigurationError("No port was selected")
```

### Pattern matching

Modern Python provides structural pattern matching:

```python
match state:
    case "created":
        ...
    case "running":
        ...
    case "stopped" | "failed":
        ...
    case _:
        raise ValueError(f"Unknown state: {state}")
```

It can make state handling readable, but it should not replace a typed state model merely because the syntax is available.

---

## 11. Exceptions and deterministic cleanup

Python reports exceptional conditions using exceptions:

```python
class FileValidationError(Exception):
    """A selected path cannot be shared safely."""


def validate_file(path: str) -> None:
    if not path:
        raise FileValidationError("A path is required")
```

Callers may handle specific errors:

```python
try:
    validate_file(user_path)
except FileValidationError as exc:
    print(f"Cannot share file: {exc}")
```

### Do not catch everything blindly

This is dangerous:

```python
try:
    start_session()
except Exception:
    pass
```

It discards the cause, may leave resources active, and tells the caller that nothing went wrong.

A better pattern preserves the original failure while attempting cleanup:

```python
try:
    session.start()
except Exception:
    session.stop()
    raise
```

Real cleanup may itself fail, which requires careful design. TorKit's architecture already states that partial startup must trigger deterministic rollback and that cleanup errors must not hide the original error.

### Context managers

Context managers encode acquisition and release:

```python
with open(path, "rb") as source:
    data = source.read()
```

The file is closed whether reading succeeds or raises an exception.

A future service could expose similar behavior:

```python
with LocalWebService() as web_service:
    web_service.serve(manifest)
```

Whether that is appropriate depends on lifecycle needs, but the concept is central: ownership should be visible in code.

---

## 12. Classes, instances, and interfaces

A class defines behavior shared by instances:

```python
class Session:
    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self.state = "created"

    def start(self) -> None:
        self.state = "running"
```

Usage:

```python
session = Session("abc123")
session.start()
print(session.state)
```

`self` is the instance passed to an instance method. Python makes it explicit in the method declaration.

### Data classes

For structured data with little behavior, `dataclasses` reduce boilerplate:

```python
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ManifestEntry:
    source_path: Path
    display_name: str
    size_bytes: int
```

`frozen=True` prevents normal attribute reassignment and communicates value-object intent. It does not turn every referenced object into deeply immutable data, but it is useful for stable models.

### Inheritance is not the only form of interface

Python supports **structural typing** through protocols:

```python
from typing import Protocol


class TorService(Protocol):
    def start(self) -> None: ...
    def stop(self) -> None: ...
```

Any object with compatible methods can satisfy the protocol for static type checking. This can support TorKit's planned `LocalOnlyTorService` and `StemTorService` without forcing every design into a deep class hierarchy.

### Composition for TorKit

The project architecture favors composition:

```text
ShareSession
├── TorService
├── WebService
├── TransferService
├── FileManifest
└── EventBus
```

A `ShareSession` coordinates these objects. It should not inherit all their behavior through a giant base class. Composition keeps ownership and replacement points visible.

---

## 13. Iteration, comprehensions, and generators

Python's iteration protocol lets many objects work with `for`:

```python
for entry in manifest_entries:
    print(entry.display_name)
```

A list comprehension builds a list:

```python
names = [entry.display_name for entry in manifest_entries]
```

A generator expression produces values lazily:

```python
sizes = (entry.size_bytes for entry in manifest_entries)
```

Laziness matters for large files or streams. TorKit should not read an entire shared file into memory just because list-oriented code is easy to write. File transfer normally requires chunked iteration:

```python
def read_chunks(path: Path, chunk_size: int = 1024 * 1024):
    with path.open("rb") as source:
        while chunk := source.read(chunk_size):
            yield chunk
```

The assignment expression `:=` binds the result while testing it. It should be used only when it improves clarity.

---

## 14. Python in TorKit today

The current Python surface is deliberately small.

### `src/torkit/__init__.py`

```python
# currently empty
```

Meaning:

- `torkit` is a regular package;
- importing `torkit` has no project-defined side effects;
- the public package API has not yet been declared.

### `src/torkit/cli.py`

```python
def main() -> None:
    print("TorKit")
```

Meaning:

- a named function is available as an entry point;
- it accepts no arguments directly;
- it declares that it returns no meaningful value;
- it currently performs one observable action;
- later application construction can remain behind the same command boundary.

### `pyproject.toml`

Relevant Python choices:

```toml
requires-python = ">=3.11"
```

TorKit is free to use Python 3.11 language and standard-library features. Supporting older interpreters would require testing and possibly compatibility code.

```toml
[project.scripts]
torkit = "torkit.cli:main"
```

The installed shell command calls the function above.

```toml
[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

Pytest is told where tests live and is given `src` on its import path for test discovery. An editable install is still the more representative development setup because it tests the installed project model.

---

## 15. How upstream OnionShare uses Python

TorKit's upstream architecture notes identify OnionShare as a Python application divided into a shared CLI/core area and a Qt desktop presentation layer. The verified desktop startup path uses `python -m onionshare`, enters `desktop/onionshare/__main__.py`, calls `main()`, constructs application objects, and then enters the Qt event loop.

That design demonstrates several Python ideas:

- `__main__.py` makes a package executable with `python -m package_name`;
- a small startup wrapper delegates to a named `main()` function;
- the GUI imports and consumes shared application logic instead of reimplementing it;
- Python coordinates Tor, the web layer, modes, settings, and desktop components;
- the project can provide multiple frontends over shared modules.

TorKit is not copying every upstream file. It is learning the separation principle and building a smaller package with explicit ownership.

A future TorKit executable-module path might look like:

```text
python -m torkit
      │
      ▼
src/torkit/__main__.py
      │
      ▼
torkit.cli.main()
```

That file does not exist yet and should not be added merely to complete a pattern. It should be introduced when the project decides to support module execution.

---

## 16. Common mistakes

### Mistake 1: Running files by path and breaking package imports

```bash
python src/torkit/cli.py
```

This may work while `cli.py` is isolated, but later relative package behavior and installed entry points can differ. Prefer the installed command:

```bash
torkit
```

or an explicitly supported module command:

```bash
python -m torkit
```

### Mistake 2: Treating annotations as runtime validation

```python
def open_port(port: int) -> None:
    ...
```

A caller may still pass a string. Validate untrusted input at boundaries.

### Mistake 3: Putting application startup at module top level

Imports should normally define objects, not launch services.

### Mistake 4: Using mutable default arguments

Bad:

```python
def add_file(path: str, files: list[str] = []) -> list[str]:
    files.append(path)
    return files
```

The same list is reused across calls.

Better:

```python
def add_file(path: str, files: list[str] | None = None) -> list[str]:
    result = [] if files is None else list(files)
    result.append(path)
    return result
```

### Mistake 5: Catching broad exceptions too early

Catch errors where you can add meaningful context or recover. Do not erase tracebacks merely to print a friendly message.

### Mistake 6: Confusing paths and strings

Use `pathlib.Path` for filesystem paths:

```python
from pathlib import Path

path = Path("README.md")
if path.is_file():
    print(path.resolve())
```

String concatenation is not a safe path model.

### Mistake 7: Building one giant `main()`

As soon as real behavior arrives, delegate parsing, construction, execution, and shutdown to focused components.

### Mistake 8: Importing internals through `__init__.py` for convenience

A short import is not worth hidden dependency cycles and accidental public APIs.

---

## 17. Laboratory exercises

Perform these in a disposable branch or without committing changes.

### Exercise 1: Observe the return value

Run:

```bash
python - <<'PY'
from torkit.cli import main

result = main()
print("returned:", repr(result))
PY
```

Explain why `None` is printed after `TorKit`.

### Exercise 2: Inspect function annotations

```bash
python - <<'PY'
from torkit.cli import main

print(main.__annotations__)
PY
```

Predict the output before running it. Determine whether the annotation changes the function's return value.

### Exercise 3: Prove that `__init__.py` executes on import

Temporarily add this line to `src/torkit/__init__.py`:

```python
print("initializing torkit")
```

Start a new interpreter and import both `torkit` and `torkit.cli`. Observe how many times the message appears in one process. Revert the change.

### Exercise 4: Inspect import locations

```bash
python - <<'PY'
import sys
import torkit

print("package file:", torkit.__file__)
print("search path:")
for item in sys.path:
    print(" -", item)
PY
```

Identify whether TorKit is imported through an editable installation, direct `PYTHONPATH` configuration, or another mechanism.

### Exercise 5: Compare identity and equality

Predict every line before running:

```python
a = ["x"]
b = ["x"]
c = a

print(a == b)
print(a is b)
print(a == c)
print(a is c)
```

### Exercise 6: Write a pure function

Write:

```python
def normalize_command_name(value: str) -> str:
    ...
```

Requirements:

- remove leading and trailing whitespace;
- convert to lowercase;
- replace spaces with hyphens;
- do not read files, print, or modify global state.

Create at least five assertions.

### Exercise 7: Model a session state

Use `enum.Enum` to define:

```text
CREATED
STARTING
RUNNING
STOPPING
STOPPED
FAILED
```

Write a function that accepts the enum and returns whether a session is terminal. Do not compare raw strings.

### Exercise 8: Demonstrate deterministic cleanup

Create a context manager that prints `start`, yields, and always prints `stop`. Raise an exception inside the `with` block and prove that cleanup still runs.

### Exercise 9: Sketch the next CLI boundary

Without modifying TorKit, write a separate example containing:

- `parse_arguments()`;
- `build_application()`;
- `run_application()`;
- `main()`.

Keep each function focused. Explain why `main()` should coordinate rather than implement the application.

---

## 18. Review questions

1. What is the difference between the distribution name `torkit` and the import package `torkit`?
2. Why can an empty `__init__.py` be the correct implementation?
3. What does `-> None` communicate, and what does it not enforce?
4. Why does the `src/` layout make an editable installation useful?
5. What code executes when a module is imported?
6. Why is global mutable session state inconsistent with TorKit's ownership rules?
7. When should a function raise an exception rather than return a special value?
8. How does a generated console script reach `torkit.cli:main`?
9. Why should TorKit avoid starting Tor during module import?
10. How does the upstream OnionShare startup path reinforce the thin-entry-point pattern?

---

## 19. Further reading and primary sources

- Python tutorial, modules and packages: <https://docs.python.org/3/tutorial/modules.html>
- Python language reference: <https://docs.python.org/3/reference/>
- Python data model: <https://docs.python.org/3/reference/datamodel.html>
- Python typing documentation: <https://docs.python.org/3/library/typing.html>
- Python packaging tutorial: <https://packaging.python.org/en/latest/tutorials/packaging-projects/>
- Source layout discussion: <https://packaging.python.org/en/latest/discussions/src-layout-vs-flat-layout/>
- OnionShare development documentation: <https://docs.onionshare.org/2.6.4/en/develop.html>
- TorKit architecture: `docs/OUR_ARCHITECTURE.md`
- TorKit upstream study: `docs/UPSTREAM_ARCHITECTURE.md`

---

## Chapter summary

Python gives TorKit a readable application language that can coordinate lower-level services without forcing every subsystem into one implementation language. The project currently contains one regular package, one empty package initializer, and one typed CLI function. Those tiny files already demonstrate the essential boundaries between packages, modules, imports, functions, type annotations, and installed entry points.

The most important lesson is architectural rather than syntactic: Python makes it easy to place behavior anywhere, so disciplined ownership matters. Imports should not launch services. `main()` should not become the application. Mutable state should have an explicit owner. Type annotations should describe interfaces, while runtime checks defend external boundaries. Those habits will determine whether TorKit remains understandable as it grows.
