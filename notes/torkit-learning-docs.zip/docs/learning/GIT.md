# Git: The Local History Engine Behind TorKit

> Repository snapshot used by this chapter: `BrentDean/torKit`, `main`, 2026-08-01.
>
> Git is not GitHub. Git is the distributed version-control system that records TorKit's history locally. This chapter builds a mental model from Git's object database outward, then applies it to the first three TorKit commits.

## Learning goals

After completing this chapter, you should be able to:

- explain why version control replaced numbered folders and manually copied backups;
- compare centralized and distributed version-control models;
- explain Git's snapshot model rather than treating commits as loose patches;
- distinguish the working tree, staging area, local repository, and remote-tracking references;
- describe blobs, trees, commits, refs, branches, tags, `HEAD`, and the index;
- create focused commits and inspect exactly what they contain;
- explain what happened when TorKit's package was renamed in a later commit;
- choose safely among restore, reset, revert, amend, and rebase;
- explain fetch, pull, and push without using “sync” as a vague substitute;
- recover work using Git's object model and reflog.

---

## 1. The problem version control solves

Without version control, projects often evolve into directories like:

```text
torkit/
torkit-new/
torkit-new-working/
torkit-final/
torkit-final-2/
torkit-final-really/
```

This approach fails to answer important questions:

- Which files changed between versions?
- Which changes belong together?
- Why was a line changed?
- Who made the change?
- Can one change be reversed without discarding later work?
- Can two people work in parallel?
- Can an experimental line of work remain separate from stable code?
- Can history be verified after transfer to another machine?

A version-control system stores project history as structured data and provides operations for comparing, branching, merging, and recovering states.

### Local version control

Early systems stored revisions on one machine. They improved file history but did little for distributed collaboration.

### Centralized version control

Systems such as CVS and Subversion use a central server as the authoritative repository.

```text
Developer A ─┐
Developer B ─┼──► central repository
Developer C ─┘
```

Advantages:

- one obvious shared authority;
- centralized permissions and administration;
- simple mental model for some workflows.

Costs:

- many history operations depend on server access;
- the central service is operationally important;
- branching behavior depends on the system;
- offline work is limited compared with a distributed model.

### Distributed version control

Git gives each normal clone a repository containing project history and objects.

```text
             shared remote
             /           \
            ▼             ▼
     Developer A       Developer B
     full local repo   full local repo
```

A developer can commit, branch, inspect history, compare revisions, and recover previous states without contacting GitHub. Network operations exchange objects and references between repositories.

---

## 2. Why Git was created

Git was created in 2005 for Linux kernel development after access to the project's previous distributed version-control system changed. The design priorities included:

- speed;
- distributed operation;
- strong integrity checking;
- efficient branching and merging;
- support for very large collaborative histories.

Git's interface can appear inconsistent because it exposes both high-level workflow commands and lower-level object operations. The internal model, however, is compact and consistent.

The most productive way to learn Git is not to memorize rescue commands. It is to understand what data each command changes.

---

## 3. Git stores snapshots

Many version-control explanations begin with differences:

```text
version 1 + patch A + patch B + patch C
```

Git conceptually records snapshots of the project. A commit points to a tree describing the state of tracked files at that moment.

```text
Commit A ──► snapshot A
Commit B ──► snapshot B
Commit C ──► snapshot C
```

Git remains space-efficient because unchanged file contents can be referenced by the same objects, and repository storage may be compressed into packfiles using delta techniques. The user-facing model is still snapshot-based.

### Why the distinction matters

A commit is not merely “the lines I typed.” It records:

- a project tree;
- parent commit reference or references;
- author and committer identities and timestamps;
- a message.

Git computes a diff between snapshots when you ask to view changes.

---

## 4. The four areas you must distinguish

A practical TorKit workflow involves four states or locations:

```text
Working tree
    │ git add
    ▼
Staging area / index
    │ git commit
    ▼
Local repository
    │ git push
    ▼
Remote repository
```

### Working tree

The files checked out on disk:

```text
docs/
src/
tests/
scripts/
pyproject.toml
README.md
```

Editing `docs/learning/PYTHON.md` changes the working tree.

### Staging area, also called the index

The proposed content of the next commit. `git add` copies selected current file content into the index.

The index is not just a list of filenames. It records object identifiers and path metadata for the exact content intended for the next snapshot.

### Local repository

The `.git/` directory stores objects, references, configuration, logs, and other repository data. `git commit` writes a commit into this local repository.

### Remote repository

Another Git repository reached through a URL. For TorKit, GitHub hosts the remote repository, but Git itself only sees a remote endpoint.

A local commit exists before it is pushed. A GitHub outage does not prevent local commits.

---

## 5. The three common file states

Git documentation commonly describes tracked files as:

- **modified** — working-tree content differs from the index;
- **staged** — index content differs from `HEAD` and is selected for the next commit;
- **committed** — content is stored in the local repository and referenced by a commit.

One file can effectively have both staged and unstaged changes:

```text
HEAD version
    │
    ├── staged edit A in index
    │
    └── additional unstaged edit B in working tree
```

Inspect each comparison separately:

```bash
git diff           # working tree versus index
git diff --cached  # index versus HEAD
git diff HEAD      # working tree versus HEAD
```

This is why `git status` and both diffs should be checked before committing.

---

## 6. Git objects

Git's core object types are:

```text
blob    file content
 tree    directory snapshot and names
commit  tree plus parent(s), identities, time, message
 tag     annotated reference to another object
```

Objects are identified by cryptographic hashes. Modern Git repositories may use SHA-1 or SHA-256 object formats depending on repository configuration and compatibility. TorKit's displayed commit identifiers are SHA-1-style hexadecimal values.

### Blob

A blob contains file bytes. It does not contain the filename. The tree supplies the name.

If two paths contain identical bytes, they may refer to the same blob object.

### Tree

A tree maps names to blobs or other trees, along with modes.

Conceptually:

```text
root tree
├── README.md ──► blob
├── pyproject.toml ──► blob
└── src ──► tree
    └── torkit ──► tree
        ├── __init__.py ──► blob
        └── cli.py ──► blob
```

### Commit

A commit points to one root tree and normally one parent:

```text
commit C
├── tree: snapshot C
├── parent: commit B
├── author
├── committer
└── message
```

A merge commit normally has multiple parents.

### Inspect objects

```bash
git cat-file -t HEAD
git cat-file -p HEAD
git ls-tree -r HEAD
```

These are lower-level commands, but they reveal the model directly.

---

## 7. References, branches, and `HEAD`

A branch is a movable reference to a commit.

```text
main ──► commit C ──► commit B ──► commit A
```

When a new commit is created on `main`, the branch moves:

```text
main ──► commit D ──► commit C ──► commit B ──► commit A
```

The branch does not contain a separate copy of every file. It is a name pointing into the commit graph.

### `HEAD`

`HEAD` normally points symbolically to the current branch:

```text
HEAD ──► refs/heads/main ──► commit D
```

In a detached-HEAD state, `HEAD` points directly to a commit. Commits can still be created, but no normal branch automatically preserves the new tip unless one is created.

### Create and switch branches

Modern command:

```bash
git switch -c docs/learning-foundation
```

Equivalent older pattern:

```bash
git checkout -b docs/learning-foundation
```

Switch back:

```bash
git switch main
```

List branches:

```bash
git branch --all --verbose
```

---

## 8. TorKit's actual first commits

At the repository snapshot used by this chapter, TorKit has three commits on `main`:

```text
aad8f18 Rename Python package to TorKit
5bb772c Add Python package and CLI foundation
7e71908 Add project planning and architecture foundation
```

This small history is an excellent teaching example.

### Commit 1: architecture foundation

```text
7e71908 Add project planning and architecture foundation
```

This established the documentation and design direction before implementation.

### Commit 2: Python package and CLI foundation

```text
5bb772c Add Python package and CLI foundation
```

It added:

- `pyproject.toml`;
- `src/onionshare_clone/__init__.py`;
- `src/onionshare_clone/cli.py`.

The project was initially named `onionshare-clone`, and the console command targeted `onionshare_clone.cli:main`.

### Commit 3: rename to TorKit

```text
aad8f18 Rename Python package to TorKit
```

The commit changed several coordinated identifiers:

```text
onionshare-clone       → torkit          distribution name
onionshare_clone       → torkit          import package
onionshare-clone       → torkit          console command
onionshare_clone.cli   → torkit.cli      entry-point module
"OnionShare Clone"     → "TorKit"        output/branding
```

This is why the change belongs in one focused commit. The snapshot should not contain half of the old identity and half of the new identity.

### Inspect locally

```bash
git log --oneline --decorate --graph --all
git show --stat 5bb772c
git show aad8f18
git diff 5bb772c aad8f18
```

The third command shows both the before and after snapshots. Git calculates the patch presentation from those snapshots.

---

## 9. Staging intentionally

Suppose six new documentation files are created. Do not blindly run `git add .` before inspection.

First:

```bash
git status --short
git diff -- docs/learning/
```

Then stage the intended paths:

```bash
git add \
  docs/learning/PYTHON.md \
  docs/learning/PYTHON_PACKAGING.md \
  docs/learning/TOML.md \
  docs/learning/VIRTUAL_ENVIRONMENTS.md \
  docs/learning/GIT.md \
  docs/learning/GITHUB.md
```

Review the staged snapshot:

```bash
git diff --cached --check
git diff --cached --stat
git diff --cached
```

`--check` identifies whitespace errors such as trailing spaces and conflict markers.

### Partial staging

If one file contains two unrelated changes:

```bash
git add -p path/to/file
```

Git presents hunks and allows selective staging. This supports commits organized by purpose rather than by editing session.

### Unstage without discarding work

```bash
git restore --staged path/to/file
```

The working-tree edit remains.

---

## 10. Writing useful commits

A commit should represent one coherent change that can be understood and, when practical, tested independently.

Good message:

```text
Add foundational learning chapters
```

Weak messages:

```text
updates
stuff
work
fixes
```

A useful subject is:

- imperative in style;
- specific;
- focused on the change;
- short enough to scan in logs.

A body can explain rationale:

```text
Add foundational learning chapters

Introduce textbook-style guides for Python, packaging, TOML,
virtual environments, Git, and GitHub. Tie examples to the
current TorKit package and initial repository history.
```

### Author and committer

Git records both:

- author — who originally created the change;
- committer — who created this commit object.

They are often the same. Rebasing, applying patches, and maintainership workflows can make them differ.

Configure identity:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

Repository-local configuration can override global values.

---

## 11. Ignored, untracked, and tracked files

### Untracked

A file exists in the working tree but is not in the index or current commit.

```text
?? docs/learning/PYTHON.md
```

### Tracked

A path appears in the index/current history.

### Ignored

An untracked path matches ignore rules and is normally hidden from status and broad add commands.

Common Python ignores:

```gitignore
.venv/
__pycache__/
*.py[cod]
build/
dist/
*.egg-info/
.pytest_cache/
```

Ignore rules do not automatically stop tracking a file already committed.

Inspect why a path is ignored:

```bash
git check-ignore -v .venv/bin/python
```

### `.gitignore` is not a security boundary

Do not store secrets in the repository and assume ignore rules make them safe. An accidental forced add, archive, backup, or command history can expose them. Use proper secret management and review staged content.

---

## 12. Remotes, fetch, pull, and push

A remote is a named set of repository URLs. The conventional first remote is `origin`.

```bash
git remote -v
```

For TorKit, the remote points to the GitHub repository `BrentDean/torKit`.

### Fetch

```bash
git fetch origin
```

Fetch downloads objects and updates remote-tracking references such as `origin/main`. It does not automatically modify the current branch or working tree.

```text
before fetch:
origin/main ──► commit C
main        ──► commit C

remote gains D

fetch:
origin/main ──► commit D
main        ──► commit C
```

### Pull

`git pull` is a convenience operation that fetches and then integrates the selected upstream branch, normally by merge or rebase depending on configuration.

Because it performs multiple operations, beginners should understand fetch and integration separately before relying on pull.

### Push

```bash
git push origin main
```

Push sends local objects and requests an update to the remote branch.

A push can be rejected when the remote branch contains commits the local branch does not include. The solution is not automatic force. Fetch, inspect, and integrate the remote work.

### Remote-tracking branch

`origin/main` is a local reference representing the last fetched state of the remote's `main`. It is not a live network pointer.

---

## 13. Merging and rebasing

Assume:

```text
A──B──C main
    \
     D──E docs-branch
```

### Merge

Merging `docs-branch` into `main` may create:

```text
A──B──C────M main
    \      /
     D────E
```

`M` has two parents. The graph preserves the fact that work developed in parallel.

If `main` has not moved since the branch point, Git may perform a fast-forward:

```text
A──B main
    \
     C──D docs-branch
```

After fast-forward:

```text
A──B──C──D main, docs-branch
```

No merge commit is needed.

### Rebase

Rebasing replays changes onto a different base:

Before:

```text
A──B──C main
    \
     D──E docs-branch
```

After rebasing the branch onto `main`:

```text
A──B──C main
       \
        D'──E' docs-branch
```

`D'` and `E'` are new commits with new identifiers, because their parent history changed.

### Policy

- merge preserves branch topology;
- rebase can create a linear story;
- rebasing unpublished personal commits is usually straightforward;
- rebasing shared commits rewrites history others may already reference;
- either workflow requires review and tests.

Do not use rebase merely because a command recipe says history should be “clean.” Understand which commits will be replaced.

---

## 14. Conflicts

A conflict occurs when Git cannot automatically combine changes.

Example conflict markers:

```text
<<<<<<< HEAD
name = "torkit"
=======
name = "tor-kit"
>>>>>>> feature-branch
```

These markers are not alternative syntax to leave in the file. The developer must decide the correct content, remove markers, stage the resolution, and continue the operation.

Useful commands:

```bash
git status
git diff --check
```

Abort a merge:

```bash
git merge --abort
```

Abort a rebase:

```bash
git rebase --abort
```

Continue after resolving and staging:

```bash
git merge --continue
# or
git rebase --continue
```

The right resolution depends on project intent, not on choosing “ours” or “theirs” mechanically.

---

## 15. Undoing safely

“Undo” is ambiguous. Ask which data should change.

```text
working tree?
staging area?
current branch pointer?
published history?
one file or the entire snapshot?
```

### Discard an unstaged file change

```bash
git restore path/to/file
```

This overwrites working-tree content with the index version. Inspect first; the discarded edit may not be recoverable through Git if it was never staged or committed.

### Unstage a file

```bash
git restore --staged path/to/file
```

Working-tree content remains.

### Amend the latest local commit

```bash
git commit --amend
```

This creates a new commit replacing the branch tip. If the old commit was already pushed and shared, amendment implies history rewriting.

### Revert a published commit

```bash
git revert <commit>
```

Creates a new commit applying the inverse change. This preserves shared history and is normally safer for published branches.

### Reset a branch

```bash
git reset --soft <commit>
git reset --mixed <commit>
git reset --hard <commit>
```

These modes move the current branch and differ in how they update the index and working tree.

```text
--soft   move branch; keep index and working tree
--mixed  move branch; reset index; keep working tree
--hard   move branch; reset index and working tree
```

`--hard` can destroy uncommitted work. Do not use it as a generic cleanup command.

### Recover with reflog

Git records recent reference movements locally:

```bash
git reflog
```

If a branch was reset or a rebase went wrong, the old commit may still be reachable through the reflog until cleanup removes unreachable objects.

Create a recovery branch:

```bash
git branch recovery/<name> <old-commit>
```

---

## 16. Tags and releases

A tag is a named reference generally used for important versions.

Lightweight tag:

```bash
git tag v0.1.0
```

Annotated tag:

```bash
git tag -a v0.1.0 -m "TorKit 0.1.0"
```

Annotated tags store a tag object with metadata and can be signed.

Tagging policy should align with package versions and release procedures. TorKit currently declares version `0.1.0`, but a metadata value alone does not prove that a release tag or published artifact exists.

Do not create or move release tags casually after artifacts are distributed.

---

## 17. Good TorKit documentation workflow

For a substantial documentation addition:

```bash
git switch -c docs/learning-foundation
```

Create and inspect files:

```bash
git status --short
git diff --check
git diff --stat
```

Stage only the documentation:

```bash
git add docs/learning/
```

Review the exact commit:

```bash
git diff --cached --check
git diff --cached --stat
git diff --cached
```

Commit:

```bash
git commit -m "Add foundational learning chapters"
```

Verify:

```bash
git status --short --branch
git show --stat --oneline HEAD
```

Push only when the branch and destination are deliberate:

```bash
git push -u origin docs/learning-foundation
```

GitHub pull-request behavior belongs to the next chapter. Git has already completed the local history work before that step.

---

## 18. Common mistakes

### Mistake 1: Thinking `git add` means “add the filename forever”

It stages the current content. Further edits are unstaged until added again.

### Mistake 2: Treating `git commit` as a server upload

Commit is local. Push exchanges objects with a remote.

### Mistake 3: Using `git pull` without knowing the integration policy

Inspect `git status`, upstream configuration, and fetched history. Decide whether merge or rebase is intended.

### Mistake 4: Force-pushing shared history casually

A force update can remove commits from the remote branch's visible history. Use `--force-with-lease` only when history rewriting is intentional and coordinated.

### Mistake 5: Committing unrelated changes together

A commit titled “Add docs” should not also change application behavior, dependencies, and editor settings without a reason.

### Mistake 6: Using `git reset --hard` to make warnings disappear

It changes data. Read the status and preserve needed work first.

### Mistake 7: Assuming an ignored secret was never recorded

If it was previously committed, adding it to `.gitignore` does not remove it from history.

### Mistake 8: Confusing branch names with directories

`docs/learning-foundation` is one reference name. The slash is organizational naming, not a filesystem tree of branches.

### Mistake 9: Editing while conflict markers remain

Run `git diff --check` before committing.

### Mistake 10: Believing commit hashes are random IDs

They are derived from object content and metadata. Changing a commit's parent, message, timestamp, or tree changes its identifier.

---

## 19. Laboratory exercises

Use a disposable clone or temporary repository for destructive experiments.

### Exercise 1: Build a repository from scratch

```bash
mkdir /tmp/git-lab
cd /tmp/git-lab
git init
printf 'one\n' > lesson.txt
git add lesson.txt
git commit -m "Add first lesson"
```

Inspect `.git/`, `git status`, and `git log`.

### Exercise 2: Prove staging captures content

1. Edit `lesson.txt` to add `two`.
2. Stage it.
3. Edit it again to add `three`.
4. Compare `git diff` and `git diff --cached`.
5. Commit only the staged version.

Explain why `three` remains in the working tree.

### Exercise 3: Inspect objects

Use:

```bash
git rev-parse HEAD
git cat-file -p HEAD
git ls-tree HEAD
git cat-file -p <blob-id>
```

Trace the commit to the file bytes.

### Exercise 4: Demonstrate a branch as a pointer

Create a branch, make one commit, and draw the commit graph before and after. Use:

```bash
git log --graph --oneline --decorate --all
```

### Exercise 5: Reproduce a merge conflict

Create two branches that change the same line differently. Merge and resolve the conflict. Inspect the merge commit's parents.

### Exercise 6: Rebase and compare identifiers

Create a two-commit feature branch, move `main`, and rebase the feature branch. Record commit IDs before and after. Explain why they changed.

### Exercise 7: Revert versus reset

In a temporary repository:

- revert a commit and inspect history;
- reset another branch to its parent and inspect history;
- explain which operation is safer for published work.

### Exercise 8: Explore TorKit history

In TorKit:

```bash
git show --stat 7e71908
git show --stat 5bb772c
git show --stat aad8f18
git diff 5bb772c aad8f18 -- pyproject.toml
```

List every identity changed by the rename commit.

### Exercise 9: Create a patch

```bash
git format-patch -1 HEAD
```

Inspect the patch as text. Explain how it differs from a Git bundle or a ZIP of the working tree.

### Exercise 10: Recover a reset commit

Create a commit in a temporary repository, record its ID, reset the branch backward, then recover the commit using `git reflog` and a new branch.

---

## 20. Review questions

1. What does a Git commit point to?
2. Why is Git described as snapshot-based even though it displays diffs?
3. What is the difference between the index and the working tree?
4. Why can one file contain both staged and unstaged edits?
5. What makes a branch inexpensive?
6. What does `origin/main` represent after a fetch?
7. How does a merge commit differ from a rebased commit?
8. When is revert preferable to reset?
9. Why did TorKit's package rename change multiple identifiers in one commit?
10. How can the reflog recover a commit no longer referenced by a branch?

---

## 21. Further reading and primary sources

- Pro Git, About Version Control: <https://git-scm.com/book/en/v2/Getting-Started-About-Version-Control>
- Pro Git, What Is Git?: <https://git-scm.com/book/en/v2/Getting-Started-What-is-Git%3F>
- Pro Git, Git Basics: <https://git-scm.com/book/en/v2/Git-Basics-Getting-a-Git-Repository>
- Pro Git, Branching: <https://git-scm.com/book/en/v2/Git-Branching-Branches-in-a-Nutshell>
- Pro Git, Reset Demystified: <https://git-scm.com/book/en/v2/Git-Tools-Reset-Demystified>
- Git reference manual: <https://git-scm.com/docs>
- `gitcore-tutorial`: <https://git-scm.com/docs/gitcore-tutorial>
- TorKit history: `git log --oneline --decorate --graph --all`

---

## Chapter summary

Git is a distributed snapshot database with a working tree, an explicit staging area, local object storage, movable references, and network operations for exchanging objects with other repositories. Commands become less mysterious when each is understood as changing one or more of those data structures.

TorKit's first three commits already demonstrate a sound history: architecture was documented, a minimal Python package was added, and a coordinated rename changed the distribution, import package, entry point, and branding together. Future work should preserve that clarity through focused staging, reviewable commits, deliberate branching, and safe history operations.
