# GitHub: Hosting, Collaboration, and Review for TorKit

> Repository snapshot used by this chapter: `BrentDean/torKit`, private repository, default branch `main`, 2026-08-01.
>
> GitHub hosts a Git repository and adds identity, permissions, reviews, issues, automation, releases, and security features. This chapter separates those services from Git itself and applies them to TorKit's current repository and to upstream OnionShare collaboration.

## Learning goals

After completing this chapter, you should be able to:

- explain the difference between Git and GitHub;
- describe how a local repository is connected to GitHub through a remote URL;
- compare SSH and HTTPS authentication for Git operations;
- explain private and public repository visibility without confusing it with software licensing;
- describe branches, pull requests, reviews, status checks, issues, releases, and Actions;
- design a safe documentation pull-request workflow for TorKit;
- explain what GitHub stores that a plain Git server does not;
- identify which GitHub features are appropriate now and which would be premature;
- compare GitHub with GitLab, Bitbucket, Codeberg, Gitea, Forgejo, and self-hosted Git;
- understand how upstream OnionShare uses GitHub as a public contribution surface.

---

## 1. Git is not GitHub

Git is software and a data model. GitHub is a hosted collaboration platform built around Git repositories.

```text
Git
├── commits
├── branches
├── tags
├── object database
├── diffs
├── merge and rebase
├── fetch and push protocols
└── local history operations

GitHub
├── hosts Git repositories
├── user and organization accounts
├── repository permissions
├── pull requests and reviews
├── issues and discussions
├── Actions and status checks
├── release pages and artifacts
├── web UI and APIs
├── security scanning and advisories
└── project-management features
```

You can use Git without GitHub. You can host a Git repository on another forge, a private server, a shared filesystem, or an SSH-accessible machine.

You cannot meaningfully use most GitHub repository features without Git because branches, commits, and diffs are the foundation they present.

### A useful test

Ask where an operation happens:

```text
git commit                local Git repository
git branch                local Git repository
git diff                  local files/repository
git push origin main      Git network operation to remote
open pull request         GitHub platform operation
request review            GitHub platform operation
run GitHub Actions        GitHub automation platform
```

This prevents the common phrase “GitHub committed my code,” which hides the actual workflow.

---

## 2. Why hosted forges exist

A Git repository can be shared over SSH or HTTP without a large platform. Teams still need additional coordination:

- Who may read or write?
- Which branch is the default?
- How are changes proposed before merging?
- Where are review discussions recorded?
- Which automated tests passed?
- Which bugs and feature requests are open?
- Which commit corresponds to a release?
- Where are release notes and artifacts published?
- How are security reports handled privately?
- How are integrations authenticated?

GitHub packages these concerns into a hosted service.

```text
Developer branch
      │ push
      ▼
GitHub branch
      │
      ├── pull request discussion
      ├── automated checks
      ├── review comments
      ├── approvals / change requests
      └── merge decision
             │
             ▼
        default branch
```

The platform is valuable because the social and verification context stays attached to the Git history.

---

## 3. The current TorKit repository

Current repository identity:

```text
Owner:          BrentDean
Repository:     torKit
Full name:      BrentDean/torKit
Visibility:     private
Default branch: main
```

Current top-level project shape:

```text
docs/
src/
tests/
scripts/
pyproject.toml
README.md
```

Current history begins with:

```text
7e71908 Add project planning and architecture foundation
5bb772c Add Python package and CLI foundation
aad8f18 Rename Python package to TorKit
```

The GitHub repository stores those Git commits and presents them through a web interface. It also stores repository-level metadata such as visibility, permissions, pull requests, and issues, which are not ordinary files in the commit tree.

### Repository name versus package name

```text
GitHub repository: BrentDean/torKit
Python distribution: torkit
Python import package: torkit
CLI command: torkit
```

GitHub repository names are case-preserving identifiers in URLs and UI. Python distribution normalization and import rules are different systems. Similar naming improves clarity but should not collapse the concepts.

---

## 4. Connecting a local repository to GitHub

Git names remote repositories. The conventional first remote is `origin`.

Inspect:

```bash
git remote -v
```

An SSH configuration may look like:

```text
origin  git@github.com:BrentDean/torKit.git (fetch)
origin  git@github.com:BrentDean/torKit.git (push)
```

An HTTPS configuration may look like:

```text
origin  https://github.com/BrentDean/torKit.git (fetch)
origin  https://github.com/BrentDean/torKit.git (push)
```

Add a remote:

```bash
git remote add origin git@github.com:BrentDean/torKit.git
```

Change its URL:

```bash
git remote set-url origin git@github.com:BrentDean/torKit.git
```

The remote name has no built-in authority. `origin` is only a local label. A repository may have:

```text
origin      your GitHub repository
upstream    original project repository
backup      another Git server
```

For a fork-based workflow around OnionShare, `origin` might be the contributor's fork and `upstream` the official `onionshare/onionshare` repository.

---

## 5. Clone, fetch, pull, and push in the GitHub context

### Clone

```bash
git clone git@github.com:BrentDean/torKit.git
```

Cloning normally:

- creates a local directory;
- initializes its Git repository;
- adds `origin`;
- downloads repository objects and refs;
- creates remote-tracking branches;
- checks out the default branch.

GitHub supplies the remote endpoint and permissions. Git performs the clone.

### Fetch

```bash
git fetch origin
```

Downloads new objects and updates local remote-tracking refs. It does not merge into the current branch.

### Pull

```bash
git pull
```

Fetches and integrates according to branch and pull configuration. GitHub is only the remote host; merge or rebase is performed by local Git.

### Push

```bash
git push -u origin docs/learning-foundation
```

Uploads missing objects and asks GitHub to create or update the named remote branch. `-u` records an upstream relationship for later shorthand commands.

GitHub may reject the update because of:

- missing permission;
- branch protection;
- non-fast-forward history;
- authentication failure;
- repository rules;
- secret-scanning push protection;
- size or policy limits.

The exact error matters. “Push failed” is not one diagnosis.

---

## 6. Authentication: SSH and HTTPS

GitHub must authenticate write operations and access to private repositories.

### SSH

SSH uses a key pair:

```text
private key    remains on your machine
public key     added to GitHub account
```

The private key proves control by signing authentication data. It should never be uploaded to GitHub, committed, emailed, or pasted into documentation.

Generate an Ed25519 key where supported:

```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
```

Add the private key to the agent:

```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519
```

Add the **public** file contents to GitHub:

```bash
cat ~/.ssh/id_ed25519.pub
```

Test:

```bash
ssh -T git@github.com
```

A successful authentication message explains that GitHub does not provide shell access. The command is testing Git transport identity, not opening a normal server shell.

### Named keys and multiple accounts

A developer may use a custom key name:

```text
~/.ssh/github_brentdean
```

An SSH config can select it:

```sshconfig
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/github_brentdean
    IdentitiesOnly yes
```

For multiple GitHub identities, host aliases are clearer:

```sshconfig
Host github-brent
    HostName github.com
    User git
    IdentityFile ~/.ssh/github_brentdean
    IdentitiesOnly yes
```

Then the remote uses the alias:

```text
git@github-brent:BrentDean/torKit.git
```

### HTTPS

HTTPS remotes use URLs beginning with `https://`. Authentication normally relies on credential helpers, personal access tokens, GitHub CLI, or organization-specific identity flows. Account passwords are not used as Git passwords.

Advantages:

- works through networks that restrict SSH;
- credential helpers can integrate with desktop key stores;
- familiar proxy behavior.

SSH advantages:

- strong key-based workflow;
- convenient for repeated command-line use;
- per-key identity and access control;
- no token entered for each operation when the agent is configured.

Neither protocol changes Git history semantics.

---

## 7. Repository visibility, permissions, and licensing

### Visibility

A private repository restricts who can view its content through GitHub. A public repository is visible to anyone.

Visibility does not itself define legal permission to copy, modify, or redistribute software. Licensing does that.

TorKit currently declares:

```toml
license = "GPL-3.0-or-later"
```

The repository should also contain the corresponding license text when distribution begins. A private repository can still contain GPL-licensed work. A public repository without a clear license does not automatically grant broad reuse rights.

### Permission levels

GitHub repositories can assign roles such as read, triage, write, maintain, and admin, depending on account and organization context.

Permissions govern platform actions:

- reading private content;
- pushing branches;
- managing issues;
- merging pull requests;
- changing repository settings;
- managing collaborators.

Git commit authorship does not prove GitHub authorization. A commit object can claim an author identity; the push and review trail shows how it entered the hosted repository.

### Signed and verified commits

GitHub can display verification for commits or tags signed through supported cryptographic mechanisms. Verification indicates a signature relationship, not that the code is correct or safe.

---

## 8. Branches on GitHub

GitHub displays branches stored as refs in the hosted Git repository and adds management features.

The default branch is the repository's primary branch for:

- initial clone checkout;
- repository page display;
- default pull-request base;
- some automation defaults;
- branch protection and rules.

TorKit's default branch is `main`.

### Feature branch

For the learning documents:

```bash
git switch -c docs/learning-foundation
```

After local commits:

```bash
git push -u origin docs/learning-foundation
```

GitHub now has both:

```text
main
docs/learning-foundation
```

The branch creates an isolated proposal surface. It does not duplicate the entire repository storage.

### Protected branches and rulesets

GitHub can restrict updates to important branches. Policies may require:

- pull requests;
- approvals;
- passing status checks;
- signed commits;
- linear history;
- successful deployments;
- no force pushes;
- no deletion.

For a one-person early project, strict rules can add friction without much benefit. As TorKit gains contributors or release importance, rules can protect `main` from accidental direct pushes and unreviewed failures.

Policy should match actual risk and team size.

---

## 9. Pull requests

A pull request proposes merging changes from a **head** branch into a **base** branch.

For TorKit:

```text
head: docs/learning-foundation
base: main
```

A pull request is not a special kind of Git commit. It is GitHub metadata around a branch comparison.

```text
Git data
├── base branch commits
├── head branch commits
└── calculated diff

GitHub pull-request data
├── title and description
├── comments
├── reviewers
├── inline review threads
├── checks
├── labels and milestones
├── merge state
└── event timeline
```

### Why use a pull request when working alone?

- review the complete diff in a separate interface;
- preserve rationale and test evidence;
- run automated checks before merging;
- practice the workflow expected in collaborative projects;
- create a searchable record of architectural decisions;
- reduce accidental direct changes to `main`.

A pull request should not be ceremonial. Its description should explain what changed, why, how it was checked, and what remains intentionally out of scope.

### Example description structure

```markdown
## Summary

- add six textbook-style learning chapters;
- connect examples to the current TorKit package and history;
- include exercises and primary-source references.

## Scope

Documentation only. No source-code or architecture changes.

## Validation

- checked Markdown structure and internal paths;
- verified commands and current repository metadata;
- reviewed generated patch for documentation-only changes.
```

### Draft pull requests

A draft pull request signals that the proposal is visible but not ready for final review or merge. It is useful for early feedback. It should not become a permanent substitute for completing and validating work.

---

## 10. Reviews

Reviewers can:

- comment without approval;
- approve;
- request changes;
- comment on specific lines;
- suggest replacement text;
- resolve discussion threads.

Review should evaluate more than grammar. For educational documentation, review questions include:

- Does the technical explanation match actual TorKit files?
- Are future examples clearly marked as hypothetical?
- Are Git and GitHub kept distinct?
- Are destructive commands labeled and scoped safely?
- Do exercises teach through observation?
- Are source references primary and current?
- Does the text duplicate architecture documents instead of teaching technology?

### Review comments are not Git history

A clone contains commits, branches, and tags, but ordinary Git operations do not include GitHub pull-request review threads. Those are platform data accessible through GitHub's UI and APIs.

For long-term critical decisions, capture durable outcomes in repository documentation or commit/PR descriptions rather than relying only on a transient comment thread.

---

## 11. Merge methods

GitHub commonly offers three pull-request merge styles.

### Merge commit

Preserves branch commits and creates a merge commit:

```text
A──B──C────M main
    \      /
     D────E feature
```

Advantages:

- preserves branch topology;
- explicit integration event;
- useful for grouped work.

### Squash merge

Combines the pull request's changes into one new commit on the base branch:

```text
A──B──C──S main
```

Advantages:

- concise main-branch history;
- intermediate “fix review typo” commits do not remain individually.

Cost:

- original feature commit identities are not the commits placed on `main`;
- detailed branch history becomes less central after deletion.

### Rebase merge

Replays individual commits onto the base branch without a merge commit:

```text
A──B──C──D'──E' main
```

Advantages:

- linear history;
- retains separate logical commits.

Cost:

- commit IDs change;
- branch topology is not preserved.

TorKit should choose a policy deliberately. A six-document foundation may fit one focused commit or a small series of logically separated document commits. The merge method should reinforce that structure rather than compensate for poor local history.

---

## 12. Issues, discussions, and project planning

### Issues

Issues track discrete work, defects, questions, or proposals.

Useful issue:

```text
Title: Add educational chapter for Waitress

Acceptance criteria:
- explain WSGI and production server role;
- tie examples to the first TorKit web-service implementation;
- include comparison with Flask development server;
- add exercises and primary sources.
```

Weak issue:

```text
Title: Docs
Body: Make docs better
```

Issues can include labels, assignees, milestones, linked pull requests, and task lists.

### Discussions

GitHub Discussions supports longer-lived questions, design exploration, announcements, and community conversation. For a private one-person project it may be unnecessary. Architecture decisions that govern code should remain in the repository's decision records, not only in a platform forum.

### Projects

GitHub Projects can organize issues and pull requests into boards and roadmaps. TorKit already has repository documents such as `PROJECT_ROADMAP.md` and `SUBSYSTEM_TRACKER.md`. Introducing another tracker should solve a real coordination problem rather than duplicate status in two places.

---

## 13. GitHub Actions and status checks

GitHub Actions runs workflows defined in repository files, normally under:

```text
.github/workflows/
```

A workflow can respond to events such as:

- pushes;
- pull requests;
- tags;
- manual dispatch;
- schedules;
- releases.

A future minimal TorKit workflow might:

```text
checkout repository
set up supported Python versions
install TorKit and test dependencies
run tests
build wheel and sdist
inspect or upload test artifacts
```

Conceptual YAML:

```yaml
name: test

on:
  pull_request:
  push:
    branches: [main]

jobs:
  pytest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: python -m pip install -e .
      - run: python -m pytest
```

This is an educational example, not a statement that TorKit currently has this workflow.

### Status checks

Workflow jobs and external integrations can report checks on commits and pull requests. Branch rules may require them before merge.

Checks answer questions such as:

- Did tests pass on a clean runner?
- Did the package build?
- Did a linter reject formatting?
- Did security analysis report a problem?

They do not prove correctness. They prove that configured checks produced recorded outcomes.

### Security considerations

Workflow code can access repository content and, under controlled conditions, secrets or tokens. Pull-request events from forks require careful permissions. Pin trusted actions appropriately, limit token permissions, and do not expose secrets to untrusted code.

Automation should be introduced when there are real tests or repeatable checks to run, not merely to display a green badge.

---

## 14. Releases and artifacts

A GitHub release is platform metadata usually associated with a Git tag. It may include:

- title and release notes;
- source archives generated by GitHub;
- uploaded binaries or packages;
- prerelease designation;
- discussion links.

A release is not the same as a branch or a package-index upload.

Potential TorKit release relationship:

```text
pyproject version 0.1.0
        │
        ├── Git tag v0.1.0
        ├── GitHub release v0.1.0
        ├── wheel/sdist build
        └── optional platform artifacts
```

These should agree through a documented release process.

### Source archives caveat

GitHub-generated source archives represent repository content at a tag or commit. They are not necessarily equivalent to a Python sdist built by Hatchling. The sdist follows Python packaging inclusion and metadata rules.

### Do not release placeholders

TorKit's current version is `0.1.0`, but version metadata alone does not require a GitHub release. Create releases when there is a defined consumer, tested artifact, and meaningful release boundary.

---

## 15. Security features

GitHub offers repository security features that may include:

- dependency graph;
- Dependabot alerts and updates;
- secret scanning;
- push protection;
- code scanning;
- private vulnerability reporting;
- security advisories;
- rulesets and protected branches.

Availability depends on repository visibility, plan, language, and configuration.

### Security is layered

```text
GitHub account security
├── strong password
├── multifactor authentication
├── SSH/token review
└── recovery controls

Repository security
├── least privilege
├── branch rules
├── dependency visibility
├── secret scanning
└── review policy

Application security
├── threat modeling
├── safe defaults
├── tests
├── dependency review
└── secure implementation
```

GitHub features cannot replace TorKit's architecture-level security requirements, especially around local binding, file allowlists, Tor lifecycle, secret logging, and deterministic cleanup.

### Never commit secrets

Examples:

- private SSH keys;
- GitHub tokens;
- Tor private keys;
- API credentials;
- passwords;
- signing keys;
- production configuration containing secrets.

If a secret is committed, deleting the visible file in a later commit is insufficient. Revoke or rotate the secret first, then determine whether history rewriting is necessary and coordinate it carefully.

---

## 16. Forks and upstream projects

A fork is a GitHub-hosted repository relationship commonly used when a contributor cannot or should not push branches directly to the upstream repository.

Typical OnionShare contribution model:

```text
onionshare/onionshare          official upstream
          │ fork
          ▼
your-account/onionshare        contributor fork
          │ clone
          ▼
local repository
```

Recommended remotes:

```text
origin    git@github.com:your-account/onionshare.git
upstream  https://github.com/onionshare/onionshare.git
```

Workflow:

```bash
git fetch upstream
git switch main
git merge --ff-only upstream/main
git push origin main
git switch -c feature/my-change
```

After pushing the feature branch to the fork, open a pull request into the official repository.

Upstream OnionShare's development documentation explicitly directs contributors to clone the Git repository and submit pull requests for maintainer review. GitHub is therefore part of the project's contribution process, while Git remains the underlying version history.

---

## 17. GitHub APIs and command-line tooling

GitHub provides web APIs and the `gh` command-line client for platform actions.

Examples:

```bash
gh repo view BrentDean/torKit
gh pr create --draft
gh pr status
gh issue list
```

These commands operate on GitHub concepts such as pull requests and issues. They do not replace Git commands for staging and committing.

A typical combined workflow:

```bash
git switch -c docs/learning-foundation
git add docs/learning/
git commit -m "Add foundational learning chapters"
git push -u origin docs/learning-foundation
gh pr create --draft
```

The separation is explicit:

```text
git     creates and publishes branch history
gh      creates GitHub pull-request metadata
```

Automation using APIs should use least-privilege tokens and should not embed credentials in scripts or repository files.

---

## 18. Alternatives to GitHub

### GitLab

A hosted and self-managed forge with repositories, merge requests, CI/CD, issues, registries, and security features. Its integrated DevOps model is broad.

### Bitbucket

Atlassian's Git hosting platform, often integrated with Jira and enterprise workflows.

### Codeberg

A community-oriented public forge based on Forgejo, emphasizing open-source hosting and nonprofit governance.

### Gitea and Forgejo

Lightweight self-hostable forges. They provide repository hosting, issues, pull/merge requests, and other collaboration features without relying on GitHub's infrastructure.

### Plain Git server

A project can host bare repositories over SSH or HTTP. This provides Git exchange but not necessarily review, issues, automation, or a rich web UI.

### Choosing a forge

Consider:

- public community location;
- private-repository needs;
- authentication and organization integration;
- CI runner requirements;
- API and automation ecosystem;
- data residency;
- self-hosting capacity;
- cost;
- migration and mirroring;
- contributor familiarity.

TorKit currently uses GitHub because the repository and upstream OnionShare ecosystem are already there. The code should not depend on GitHub at runtime.

---

## 19. A safe TorKit documentation pull-request workflow

### 1. Confirm repository and branch

```bash
git remote -v
git status --short --branch
git log -1 --oneline --decorate
```

### 2. Update local knowledge of the remote

```bash
git fetch --prune origin
```

### 3. Create a branch from the intended base

```bash
git switch main
git merge --ff-only origin/main
git switch -c docs/learning-foundation
```

### 4. Add only documentation

```bash
git status --short
git add docs/learning/
```

### 5. Review staged content

```bash
git diff --cached --check
git diff --cached --stat
git diff --cached
```

### 6. Commit locally

```bash
git commit -m "Add foundational learning chapters"
```

### 7. Push the branch

```bash
git push -u origin docs/learning-foundation
```

### 8. Open a draft pull request

Use the GitHub UI or:

```bash
gh pr create --draft \
  --base main \
  --head docs/learning-foundation \
  --title "Add foundational learning chapters"
```

### 9. Review scope

Confirm that the pull request changes only:

```text
docs/learning/PYTHON.md
docs/learning/PYTHON_PACKAGING.md
docs/learning/TOML.md
docs/learning/VIRTUAL_ENVIRONMENTS.md
docs/learning/GIT.md
docs/learning/GITHUB.md
```

### 10. Merge only after validation

Choose the merge method according to repository policy, then delete the feature branch if it is no longer needed.

This workflow is a recommendation, not a remote change performed by this document.

---

## 20. Common mistakes

### Mistake 1: Saying GitHub is the local repository

The local `.git/` directory remains a full Git repository. GitHub is a remote host and collaboration service.

### Mistake 2: Uploading the private SSH key

GitHub receives the public key only. The private key remains protected locally.

### Mistake 3: Treating repository visibility as a license

Private/public controls access. Licensing controls legal reuse.

### Mistake 4: Opening a pull request with unrelated files

Review the changed-file list and base/head branches before requesting review.

### Mistake 5: Merging because checks are green

Checks cover only configured behavior. Human scope and security review remain necessary.

### Mistake 6: Using a GitHub release as the only version definition

Coordinate tags, package metadata, release notes, and artifacts.

### Mistake 7: Assuming deleting a branch deletes commits immediately

Commits may remain reachable through other refs, pull requests, caches, clones, or object retention.

### Mistake 8: Granting broad token permissions

Use least privilege and expiration. Prefer GitHub Apps or scoped mechanisms for automation when appropriate.

### Mistake 9: Storing architecture only in issues

Issues can be edited, closed, or inaccessible offline. Durable project decisions belong in repository documents such as TorKit's architecture and decision records.

### Mistake 10: Copying an upstream workflow without threat analysis

GitHub Actions permissions and fork behavior can create security risks. Understand event context and token access.

---

## 21. Laboratory exercises

Use TorKit only for read-only exercises unless working in an intentional branch.

### Exercise 1: Classify operations

For each command or action, label it Git, GitHub, or both:

```text
git commit
git push
gh pr create
review a line in Files changed
git fetch
create an issue
merge locally
merge with GitHub UI
```

Explain borderline cases.

### Exercise 2: Inspect remotes

```bash
git remote -v
git remote show origin
```

Identify fetch URL, push URL, default branch, and tracking relationships.

### Exercise 3: Test SSH identity

```bash
ssh -T git@github.com
```

Read the exact account name in the response. Explain why successful authentication does not provide shell access.

### Exercise 4: Trace a clone

Clone a disposable repository and inspect:

```bash
git remote -v
git branch -vv
git branch -r
git config --get remote.origin.url
```

Explain what clone configured automatically.

### Exercise 5: Compare local and remote refs

After `git fetch origin`, run:

```bash
git log --oneline --decorate --graph --all
```

Identify `main` and `origin/main`. Explain why they can differ.

### Exercise 6: Draft a TorKit pull request description

Write a complete description for the six learning documents with summary, scope, validation, and out-of-scope sections. Do not open the PR for this exercise.

### Exercise 7: Evaluate merge methods

For a branch with six commits—one per chapter—compare the history produced by merge commit, squash merge, and rebase merge. Choose one and justify it.

### Exercise 8: Design branch protection

Assume TorKit gains three contributors and automated tests. Propose minimum `main` rules. Avoid adding controls that do not address a stated risk.

### Exercise 9: Map platform-only data

List data visible in a GitHub pull request that a plain `git clone` does not normally retrieve.

### Exercise 10: Model an OnionShare fork workflow

Draw:

- official upstream;
- personal fork;
- local clone;
- `origin`;
- `upstream`;
- feature branch;
- pull-request direction.

Explain every fetch and push direction.

---

## 22. Review questions

1. What can Git do without GitHub?
2. What does GitHub add around a Git branch comparison?
3. Why is `origin` not inherently “the official repository”?
4. What is the difference between SSH authentication and commit signing?
5. Why can a private repository contain open-source-licensed code?
6. What information does a pull request preserve beyond the commits?
7. How do the three GitHub merge methods alter commit history?
8. Why should Actions workflows be treated as security-sensitive code?
9. How is a GitHub release different from a Python sdist?
10. Why is the upstream OnionShare fork model useful to TorKit's educational goals?

---

## 23. Further reading and primary sources

- GitHub Docs, remote repositories: <https://docs.github.com/en/get-started/git-basics/about-remote-repositories>
- GitHub Docs, getting changes from a remote: <https://docs.github.com/en/get-started/using-git/getting-changes-from-a-remote-repository>
- GitHub Docs, connecting with SSH: <https://docs.github.com/en/authentication/connecting-to-github-with-ssh>
- GitHub Docs, testing SSH: <https://docs.github.com/en/authentication/connecting-to-github-with-ssh/testing-your-ssh-connection>
- GitHub Docs, branches: <https://docs.github.com/en/pull-requests/reference/branches>
- GitHub Docs, pull requests: <https://docs.github.com/en/pull-requests/get-started/about-pull-requests>
- GitHub Docs, pull-request reviews: <https://docs.github.com/en/pull-requests/collaborating-with-pull-requests/reviewing-changes-in-pull-requests/about-pull-request-reviews>
- GitHub Docs, Actions: <https://docs.github.com/en/actions>
- OnionShare repository: <https://github.com/onionshare/onionshare>
- OnionShare development documentation: <https://docs.onionshare.org/2.6.4/en/develop.html>
- TorKit repository: `BrentDean/torKit`

---

## Chapter summary

GitHub is TorKit's hosted collaboration layer, not its version-control engine. Git creates commits, branches, tags, and local history. GitHub authenticates users, hosts the remote repository, presents branch comparisons as pull requests, records reviews, runs automation, manages issues, and publishes release metadata.

A disciplined TorKit workflow keeps that boundary visible: create and inspect commits locally, push a focused branch, open a reviewable pull request, run meaningful checks, and merge according to an explicit history policy. The same model scales outward to upstream OnionShare, where contributors work through forks, branches, and maintainer-reviewed pull requests.
